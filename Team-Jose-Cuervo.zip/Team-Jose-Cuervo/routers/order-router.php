<?php
include '../includes/connect.php';
include '../includes/wallet.php';

$total = $_POST['total'];
$payment_type = $_POST['payment_type'];
$ctr = $_POST['ctr'];
$convert = (int)$ctr;
$idName = "item_id";
$QtyName = "qty";
$stall = "stall";
$price = "price";
$id = "";
$user_id = $_SESSION['user_id'];
echo $convert;

for($i = $convert;$i > 0; $i--){
	$idTagName = $idName . $i;
	$qtyName = $QtyName . $i;
	$stallName =  $stall . $i;
	$priceName = $price . $i;

	echo 'this is a '.$i.'<br />';
	echo 'this is a '.$idTagName.'<br />';
	echo 'this is a '.$qtyName.'<br />';
	echo 'this is a '.$stallName.'<br />';
	echo 'this is a '.$priceName.'<br />';

	$item_id_value = $_POST[$idTagName];
	$item_qty_value = $_POST[$qtyName];
	$stall_value = $_POST[$stallName];
	$price_value = $_POST[$priceName];

	echo 'this is a id '.$item_id_value.'<br />';
	echo 'this is a qty '.$item_qty_value.'<br />';
	echo 'this is a stall '.$stall_value.'<br />';
	echo 'this is a price '.$price_value.'<br />';


	// Check connection
	if ($con->connect_error) {
	  die("Connection failed: " . $con->connect_error);
	}

	$sql = "INSERT INTO order_details (user_id,item_id,stall,qty, total) VALUES ('$user_id','$item_id_value','$stall_value','$item_qty_value','$price_value')";

	if ($con->query($sql) === TRUE) {
		$order_id = $con->insert_id;
	  echo "New record created successfully";
	} else {
	  echo "Error: " . $sql . "<br>" . $con->error;
	}

	echo "<br /> id: ".$order_id;

	$query2 = 'INSERT INTO orders (user_id,order_id,payment_type,total) VALUES (?,?,?,?)';
	$stmt2 = $con->prepare($query2);
	$stmt2->bind_param("iisi", $user_id,$order_id,$payment_type,$total);
	$stmt2->execute();

	if($stall_value=="PotatoCorner"){
					$result1 = mysqli_query($con,"SELECT * from wallet_details WHERE wallet_id = '1';");
					if($row1 = mysqli_fetch_array($result1)){
						if($_POST['payment_type'] == 'Wallet'){
							$balance1 = $row1['balance'] + $price_value;
							$sql1 = "UPDATE wallet_details SET balance = '$balance1' WHERE wallet_id = '1';";
							$con->query($sql1) === TRUE;
						}
						else{

						}
					
				}
		}

		elseif($stall_value=="KitchenCity"){
			$result1 = mysqli_query($con,"SELECT * from wallet_details WHERE wallet_id = '6';");
			if($row1 = mysqli_fetch_array($result1)){
				if($_POST['payment_type'] == 'Wallet'){
							$balance1 = $row1['balance'] + $price_value;
							$sql1 = "UPDATE wallet_details SET balance = '$balance1' WHERE wallet_id = '6';";
							$con->query($sql1) === TRUE;
						}
						else{
							
						}
		    }
		}

		elseif($stall_value=="MasterSiomai"){
			$result1 = mysqli_query($con,"SELECT * from wallet_details WHERE wallet_id = '8';");
			if($row1 = mysqli_fetch_array($result1)){
				if($_POST['payment_type'] == 'Wallet'){
							$balance1 = $row1['balance'] + $price_value;
							$sql1 = "UPDATE wallet_details SET balance = '$balance1' WHERE wallet_id = '8';";
							$con->query($sql1) === TRUE;
						}
						else{
							
						}
		    }
		}
}

if($_POST['payment_type'] == 'Wallet'){
		$balance = $balance - $total;
		$sql = "UPDATE wallet_details SET balance = '$balance' WHERE wallet_id = '$wallet_id';";
		$con->query($sql) === TRUE;
}
else{
	$sql = "UPDATE wallet_details SET balance = '$balance' WHERE wallet_id = '$wallet_id';";
	$con->query($sql) === TRUE;
}

header("location: ../orders.php");


?>
