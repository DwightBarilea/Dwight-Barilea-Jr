<?php
include '../includes/connect.php';



//$sql = "TRUNCATE items;";
$sql1 = "TRUNCATE orders;";
$sql2 = "TRUNCATE order_details;";
$sql3 = "TRUNCATE cart;";

//$con->query($sql);
$con->query($sql1);
$con->query($sql2);
$con->query($sql3);

header("location: ../admin-page.php");

  ?>
