<?php
include '../includes/connect.php';
include '../includes/wallet.php';
$status = $_POST['status'];
$id = $_POST['id'];
$sql = "UPDATE orders SET status='$status', deleted=1 WHERE order_id=$id;";
$con->query($sql);
$sql = mysqli_query($con, "SELECT * FROM orders where order_id= $id");
while($row = mysqli_fetch_array($sql)){
$total = $row['total'];
$user_id= $row['user_id'];
$sql3 = "UPDATE orders SET status='$status' WHERE user_id = $user_id and order_id = $id";
$con->query($sql3);
}
if($_POST['payment_type'] == 'Wallet'){
	$balance = $balance+$total;
	$sql1 = "SELECT wallet WHERE customer_id=$user_id;";
	if($row1 = mysqli_fetch_array($sql1))
	{
		$wallet_id=$row1['id'];
		$sql2 = "UPDATE wallet_details SET balance = '$balance' WHERE wallet_id = $wallet_id;";
		$con->query($sql2);

	}
}
header("location: ../orders.php");
?>
