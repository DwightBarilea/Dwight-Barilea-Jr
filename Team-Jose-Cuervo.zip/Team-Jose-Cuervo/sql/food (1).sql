-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2020 at 03:38 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `item_price` double NOT NULL,
  `stall` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `item_name`, `user_id`, `item_id`, `qty`, `item_price`, `stall`) VALUES
(115, 'Jumbo Fries', 2, 3, 1, 85, 'PotatoCorner'),
(116, 'Sisig with Rice', 2, 15, 1, 75, 'KitchenCity');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `price` int(11) NOT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT 0,
  `stall` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `price`, `deleted`, `stall`) VALUES
(1, 'Regular Fries', 29, 0, 'PotatoCorner'),
(2, 'Large Fries', 55, 0, 'PotatoCorner'),
(3, 'Jumbo Fries', 85, 0, 'PotatoCorner'),
(4, 'Mega Fries', 110, 0, 'PotatoCorner'),
(5, 'GigaFries', 179, 0, 'PotatoCorner'),
(6, 'Tera Fries', 209, 0, 'PotatoCorner'),
(7, 'Pork and Shrimp Siom', 38, 0, 'MasterSiomai'),
(8, 'Japanese Siomai', 42, 0, 'MasterSiomai'),
(9, 'Beef Siomai', 38, 0, 'MasterSiomai'),
(10, 'Chicken Siomai', 38, 0, 'MasterSiomai'),
(11, 'Tuna Siomai', 40, 0, 'MasterSiomai'),
(12, 'Sharks Fin Siomai', 40, 0, 'MasterSiomai'),
(13, 'Sinigang with Rice', 80, 0, 'KitchenCity'),
(14, 'Adobo with Rice', 85, 0, 'KitchenCity'),
(15, 'Sisig with Rice', 75, 0, 'KitchenCity'),
(16, 'Kaldereta with Rice', 80, 0, 'KitchenCity'),
(17, 'Hotdog with Rice', 50, 0, 'KitchenCity'),
(18, 'Fried Chicken with R', 70, 0, 'KitchenCity'),
(19, 'Kare Kare', 60, 0, 'KitchenCity'),
(22, 'Hashbrown', 39, 0, 'PotatoCorner'),
(24, 'Water', 20, 0, 'PotatoCorner');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `payment_type` varchar(16) NOT NULL DEFAULT 'Wallet',
  `total` int(11) NOT NULL,
  `status` varchar(25) NOT NULL DEFAULT 'Yet to be delivered',
  `deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `order_id`, `date`, `payment_type`, `total`, `status`, `deleted`) VALUES
(158, 2, 105, '2020-06-06 21:32:33', 'Wallet', 165, 'Yet to be delivered', 0),
(159, 2, 106, '2020-06-06 21:32:33', 'Wallet', 165, 'Yet to be delivered', 0),
(160, 2, 107, '2020-06-06 21:35:53', 'Wallet', 160, 'Yet to be delivered', 0),
(161, 2, 108, '2020-06-06 21:35:53', 'Wallet', 160, 'Yet to be delivered', 0);

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `stall` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `user_id`, `item_id`, `stall`, `qty`, `total`) VALUES
(105, 2, 14, 'KitchenCity', 1, 85),
(106, 2, 16, 'KitchenCity', 1, 80),
(107, 2, 15, 'KitchenCity', 1, 75),
(108, 2, 3, 'PotatoCorner', 1, 85);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `role` varchar(15) NOT NULL DEFAULT 'Customer',
  `vendorStall` varchar(255) NOT NULL,
  `name` varchar(15) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(16) NOT NULL,
  `email` varchar(35) DEFAULT NULL,
  `address` varchar(300) DEFAULT NULL,
  `contact` bigint(11) NOT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role`, `vendorStall`, `name`, `username`, `password`, `email`, `address`, `contact`, `verified`, `deleted`) VALUES
(1, 'vendor', 'PotatoCorner', 'PotatoCorner', 'potatocorner', 'potatocorner', 'potatocorner@iacademy.edu.ph', 'Address 1', 9898000000, 1, 0),
(2, 'Customer', '', 'James Liam', '201801020', 'pass1', '201801020@iacademy.edu.ph', 'Address 2', 9471234567, 1, 0),
(3, 'Customer', '', 'Benedick', '201801819', 'pass2', '201801819@iacademy.edu.ph', 'Address 3', 9661234567, 1, 0),
(4, 'Customer', '', 'Kaithelyn', '201801869', 'pass3', '201801869', '', 9271234567, 1, 0),
(5, 'Loading', '', 'Loading Cashier', 'loading1', 'loading1', '', '', 0, 1, 0),
(6, 'Administrator', '', 'Administrator', 'admin1', 'admin1', 'admin1@example.com', '', 0, 1, 0),
(7, 'vendor', 'KitchenCity', 'KitchenCity', 'kitchencity', 'kitchencity', 'kitchencity@iacademy.edu.ph', 'Yakal St.', 12345, 1, 0),
(8, 'Customer', '', 'April Joyce', '201809867', 'pass4', '201809867@iacademy.edu.ph', 'Address 4', 9241824281, 1, 0),
(9, 'vendor', 'MasterSiomai', 'MasterSiomai', 'mastersiomai', 'mastersiomai', 'mastersiomai@iacademy.edu.ph', 'Address 5', 9214567894, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wallet`
--

CREATE TABLE `wallet` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wallet`
--

INSERT INTO `wallet` (`id`, `customer_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 7),
(7, 8),
(8, 9);

-- --------------------------------------------------------

--
-- Table structure for table `wallet_details`
--

CREATE TABLE `wallet_details` (
  `id` int(11) NOT NULL,
  `wallet_id` int(11) NOT NULL,
  `number` varchar(16) NOT NULL,
  `cvv` int(3) NOT NULL,
  `balance` int(11) NOT NULL DEFAULT 2000
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wallet_details`
--

INSERT INTO `wallet_details` (`id`, `wallet_id`, `number`, `cvv`, `balance`) VALUES
(1, 1, '6155247490533921', 983, 821),
(2, 2, '1887587142382050', 772, 5061),
(3, 3, '4595809639046830', 532, 714),
(4, 4, '5475856443351234', 521, 2500),
(5, 5, '9076633115663264', 229, 2500),
(6, 6, '821351497073891', 433, 8469),
(7, 7, '7958643078021786', 740, 2000),
(8, 8, '5500000000000004', 657, 2649);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `customer_id` (`user_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `wallet`
--
ALTER TABLE `wallet`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customer_id` (`customer_id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `wallet_details`
--
ALTER TABLE `wallet_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `wallet_id` (`wallet_id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=162;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `wallet`
--
ALTER TABLE `wallet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `wallet_details`
--
ALTER TABLE `wallet_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
