<?php
include 'includes/connect.php';
include 'includes/wallet.php';
$total = 0;
	if($_SESSION['customer_sid']==session_id())
	{
$result = mysqli_query($con, "SELECT * FROM cart where id = $user_id");
while($row = mysqli_fetch_array($result)){
	$name = $row['name'];
	$contact = $row['contact'];
	$verified = $row['verified'];
}
?>
<?php
	require_once('view-comp/user-header.php');
?>
<style type="text/css">
	.btn {
	  display: inline-flex;
	  height: 40px;
	  width: 150px;
	  border: 2px solid #BFC0C0;
	  margin: 20px 20px 20px 20px;
	  color: black;
	  text-transform: uppercase;
	  text-decoration: none;
	  font-size: .8em;
	  letter-spacing: 1.5px;
	  align-items: center;
	  justify-content: center;
	  overflow: hidden;
	}

	span {
	  color: black;
	  text-decoration: none;
	  letter-spacing: 1px;
	}

	#button-2 {
	  position: relative;
	  overflow: hidden;
	  cursor: pointer;
	}

	#button-2 a {
	  position: relative;
	  transition: all .35s ease-Out;
	}

	#slide {
	  width: 100%;
	  height: 100%;
	  background: #BFC0C0;
	  left: -200px;
	  position: absolute;
	  padding: 0;
	  display: flex;
	  align-items: center;
	  justify-content: center;
	  transition: all .35s ease-Out;
	  bottom: 0;
	}

	#button-2:hover #slide {
	  left: 0;
	}

	#button-2:hover a {
	  color: #2D3142;

	}
	.caption{
	  border: 1px solid black;
	}
</style>
<title>Student Page</title>
<div class="w3-main" style="margin-left:300px">

	<h3>Provide Order Details to complete the transaction</h3><br>
	<form method="post" action="confirm-order.php">
		<div class="content-details">
			<label for="payment_type"><b>Payment Type</b></label>
			<br><br>
			<select id="payment_type" name="payment_type" style="width: 50%">
				<option value="Wallet" selected>Wallet</option>
				<option value="Pay on Cashier"> Pay on Cashier</option>
			</select>
		</div>
		<?php
		foreach ($_POST as $key => $value) {
			if($key == 'action' || $value == ''){
				break;
		}
		echo '<input name="'.$key.'" type="hidden" value="'.$value.'">';
		}
		?>

		<br>
		<div class="content">
			<h4><b><center>Order Summary</center></b></h4>
			<p><strong>Name: </strong><?php echo $name;?></p>
			<p><strong>ID: </strong><?php echo $user_id;?></p>
			<p><strong>Balance: </strong><?php echo $balance;?></p>
			<table width="100%">
				<tr style="text-align: left;">
					<th>Order Item</th>
					<th>Item ID</th>
					<th>Stall</th>
					<th>Quantity</th>
					<th>Price</th>
				</tr>
				<tr>
					<?php
					$user_id = $_SESSION['user_id'];
		      $sql = "SELECT * FROM cart where user_id = '$user_id'";
		      $result = $con->query($sql);
		      $ctr = 0;
		      if($result->num_rows > 0){
		       while($row = $result->fetch_assoc()){
		         $ctr = $ctr + 1;
							$price = $row["qty"]*$row["item_price"];
							$total = $total + $price;
							echo '
							<td style="text-align:left; width="15%">
				      <h5>'.$row["item_name"].'</h5></td>
							  <td>
									<span>'.$row["item_id"].'</span>
								</td>
								<td>
									<span>'.$row["stall"].'</span>
								</td>
								<td>
				        	<span>'.$ctr.' Pieces</span>
				        </td>
				        <td>
				        	<span>Php '.$price.'</span>
				        </td>
				      </tr>
				        ';
						}
					}
		    echo '<tr>
		    		<h6><strong>Total: Php '.$total.'</strong></h6>
		    	</tr><br>';
				if(!empty($_POST['description']))
				echo '<li class="collection-item avatar"><p><strong>Note: </strong>'.htmlspecialchars($_POST['description']).'</p></li>';
					?>
				</tr>
			</table>
		</div>
		<div class="input-field col s12">
			<input class="btn" type="submit" name="altSubmit" formaction="cart.php" value="Back">

			<button class="btn" id="button-2" type="submit" name="action">
				<div id="slide"><i class="fas fa-check fa-2x"></i></div>
         		<span>Confirm</span>
			</button>
		</div>
	</form>
</div>
</body>
</html>

<?php
	}
	else
	{
		if ($_SESSION['customer_sid']==session_id()) {
			header("location:index.php");
		}
		 else if($_SESSION['admin_sid']==session_id())
		{
			header("location:admin.php");
		}
		else if ($_SESSION['vendor_sid']==session_id()) {
			header("location:vendor.php");
		}
		else if ($_SESSION['loading_sid']==session_id()) {
			header("location:loading-page.php");
		}
		 else {
			header("location:login.php");
		}
}
