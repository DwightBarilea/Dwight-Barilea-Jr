<?php
include 'includes/connect.php';
include 'includes/wallet.php';

	if($_SESSION['customer_sid']==session_id())
	{
		?>
<style type="text/css">
	@import 'https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300';

	  .btn {
  display: inline-flex;
  height: 40px;
  width: 150px;
  border: 2px solid #BFC0C0;
  margin: 20px 20px 20px 20px;
  color: black;
  text-transform: uppercase;
  text-decoration: none;
  font-size: .8em;
  letter-spacing: 1.5px;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

span {
  color: black;
  text-decoration: none;
  letter-spacing: 1px;
}

#button-2 {
  position: relative;
  overflow: hidden;
  cursor: pointer;
}

#button-2 a {
  position: relative;
  transition: all .35s ease-Out;
}

#slide {
  width: 100%;
  height: 100%;
  background: #BFC0C0;
  left: -200px;
  position: absolute;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all .35s ease-Out;
  bottom: 0;
}

#button-2:hover #slide {
  left: 0;
}

#button-2:hover a {
  color: #2D3142;

}
.caption{
  border: 1px solid black;
}

</style>
<?php
	require_once('view-comp/user-header.php');
	$user_id = $_SESSION['customer_sid'];
?>
<div class="w3-main" style="margin-left:300px">
<form action="routers/remove-update.php" method="post">
  <div class="txt-heading"><h2>Food Cart</h2></div><br>
     <?php
            $user_id = $_SESSION['user_id'];
            $sql = "SELECT * FROM cart where user_id = '$user_id'";
            $result = $con->query($sql);
            $ctr = 0;
            if($result->num_rows > 0){
              while($row = $result->fetch_assoc()){
              $ctr = $ctr + 1;
							$price = $row["qty"]*$row["item_price"];
              echo '<table width="100%">
                <tr style="height:80px; background-color: white;">
                  <th colspan="3" style="text-align:left;">'.$row["stall"].'</th>
                  <th colspan="2" style="text-align:left;"><b>Price per Piece: Php '.$row["item_price"].' </b></th>
                </tr>
                <tr><br>
                  <th style="text-align:left; width="20%;>Name</th>
                  <th colspan="2" style="text-align:left;" width="55%">Quantity</th>
                  <th style="text-align:right;" width="5%">Price</th>
                  <th style="text-align:center;" width="10%">Remove</th>
                </tr>
                <tr>
                  <td style="text-align:left; width="15%">
                    <h5>'.$row["item_name"].'</h5>
                  </td>
                  <td style="text-align:right; width="5%">
                    <input type="number" name="qty'.$ctr.'"  min="0" required value="'.$row["qty"].'"  style="width: 50px;" />
                  </td>
                  <td style="text-align:right; width="10%">
                     <button type="submit" class="btn btn-warning" name="productQtyBtn'.$ctr.'"> Update </button>
                  </td>
                  <td style="text-align:right;" width="15%">
                    Php '.$price.'
                    <br />
                    <input type="hidden" name="price'.$ctr.'" value="'.$row["item_price"].'">
                  </td>
                  <td style="text-align:center;" width="15%">
                    <input type="hidden" name="id'.$ctr.'" value="'.$row["id"].'">
                    <button name="'.$ctr.'"><i class="fas fa-trash"></i></button>
                  </td>
                </tr>

              </table>

              <input type="hidden" name="ctr" value="'.$ctr.'">';
              }
            }else {
              echo '<h3 class="center-text">NO ITEMS IN CART!</h3>';
              $_SESSION['disable'] = 'style="display: none;"';
            }
            $con->close();
             ?>

   <!--  <div style="text-align: right; padding-right: 50px;">
      <?php
        $totalPrice = $price + $price;
      ?>
      <h5><b>Total Price: Php <?php echo $price ?> </b></h5>
    </div>
       -->

			</div>
		</div>
				<center>
				<div class="input-field col s12">
					<input class="btn" type="submit" name="altSubmit" formaction="index.php" value="Back">         
				</div>
			</form>
			<form action="place-order.php" method="post">
				<button class="btn" id="button-2" type="submit" name="action"> 
          <div id="slide"><i class="fas fa-angle-double-right"></i></div>
          <span>Place Order</span>
          
				</button>
			</form>
		</div>
	</center>
	</body>
</html>

<?php
	}
	else
	{
		if ($_SESSION['customer_sid']==session_id()) {
			header("location:index.php");
		}
		 else if($_SESSION['admin_sid']==session_id())
		{
			header("location:admin.php");
		}
		else if ($_SESSION['vendor_sid']==session_id()) {
			header("location:vendor.php");
		}
		else if ($_SESSION['loading_sid']==session_id()) {
			header("location:loading-page.php");
		}
		 else {
			header("location:login.php");
		}
}
