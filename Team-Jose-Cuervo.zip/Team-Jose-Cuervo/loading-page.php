<?php
include 'includes/connect.php';


	if($_SESSION['loading_sid']==session_id())
	{
		?>

<?php
require_once('view-comp/loading-header.php');
?>
		<title>Loading Page</title>

    <div class="w3-container" align="center">
    	<h1><b><i class="fas fa-utensils"></i> BEEP BEEP HERE COMES THE iAC BEEP</b></h1>
    	<h3>Balance Updating</h3>
    </div>
  </header>

	    <div class="card-body">
	    <div class="divider"></div>
         			 <!--editableTable-->
			<form class="formValidate" id="formValidate1" method="post" action="routers/user-router.php" novalidate="novalidate">
			<div class="row">
				<div class="col s12 m4 l3">
					<h4 class="header">LIST OF USERS BALANCE: </h4>
				</div>

<table class="table">
  <thead>
    <tr>
      <th width="25">Name</th>
      <th width="25">Email</th>
      <th width="25" style="text-align: center;">Balance</th>
      <th width="25" style="text-align: center;">Add Balance</th>
    </tr>
  </thead>
<tbody>
	<?php
		$result = mysqli_query($con, "SELECT * FROM users WHERE role='Customer';");
		$amount = 0;
		while($row = mysqli_fetch_array($result))
			{
				echo '<tr><td>'.$row["name"].'</td>';
				echo '<td>'.$row["email"].'</td>';

				$key = $row['id'];
				$sql = mysqli_query($con,"SELECT * from wallet WHERE customer_id = $key;");

				if($row1 = mysqli_fetch_array($sql)) {
					$wallet_id = $row1['id'];
					$sql1 = mysqli_query($con,"SELECT * from wallet_details WHERE wallet_id = $wallet_id;");
						if($row2 = mysqli_fetch_array($sql1)){
							echo '<td style="text-align: center;">'.$row2["balance"].'</td>';
							echo '<td style="text-align: center;">
							<label for="balance">Add </label> 
							<input id="balance" type="number" name="'.$row['id'].'_balance" value="'.$amount.'" data-error=".errorTxt01"  style="width: 20%"><div class="errorTxt01">
							</div>
							</td></tr>';

       							
						}
				}

				}
	?>
        </tbody>
</table>

	<div class="col text-right">
		<button class="btn" type="submit" name="action"><h5>Modify
			<i class="fas fa-angle-double-right"></i></h5>
		</button>
	</div>

				</div>
			</form>
		</div>
	</div>

</body>
</html>

<?php
	}
	else
	{
		if ($_SESSION['loading_sid']==session_id()) {
			header("location:loading-page.php");
		}
		 else if($_SESSION['customer_sid']==session_id())
		{
			header("location:index.php");
		}
		else if ($_SESSION['vendor_sid']==session_id()) {
			header("location:vendor.php");
		}
		else if ($_SESSION['admin_sid']==session_id()) {
			header("location:admin-page.php");
		}
		 else {
			header("location:login.php");
		}
}
