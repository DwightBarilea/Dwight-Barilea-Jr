<?php
include 'includes/connect.php';
include 'includes/wallet.php';
$user_id = $_SESSION['user_id'];

$result = mysqli_query($con, "SELECT * FROM users where id = $user_id");
while($row = mysqli_fetch_array($result)){
$name = $row['name'];
$address = $row['address'];
$contact = $row['contact'];
$email = $row['email'];
$username = $row['username'];
}
  if($_SESSION['customer_sid']==session_id())
  {
    ?>
  <?php
  require_once('view-comp/user-header.php');
  ?>
<html>
<title>Student Page</title>
<div class="w3-main" style="margin-left:300px">
    <div class="content">
      <h2>User Profile Page</h2>
      <p>Welcome back, <?=$_SESSION['name']?>!</p>
    </div>

    <div class="content">

      <form method="post" action = "routers/details-router.php">
        <div>
          <label>Username : </label>
          <?php
            echo $username;
           ?>
        </div>
        <br>
        <div>
          <label>Name: </label>
          <?php
            echo $name;
           ?>
        </div>
        <br>
        <div>
          <label>Email: </label>
          <?php
            echo $email;
           ?>
        </div>
        <br>
        <div>
          <label>Password: </label>
          <input name="password" id="password" type="password">
          <button>Change Password</button>
        </div>
        <br>
        <div>
          <label >Contact: </label>
          <?php
            echo $contact;
           ?>
        </div>
        <br>
        <div>
          <label>Balance:</label>
          <?php
            echo $balance;
           ?>
        </div>
        <br>
        <div>
          <label>Address</label>
          <?php
            echo $address;
           ?>
        </div>
      </form>
    </div>
</body>
</html>

<?php
  }
  else
  {
    if ($_SESSION['customer_sid']==session_id()) {
      header("location:index.php.php");
    }
     else if($_SESSION['admin_sid']==session_id())
    {
      header("location:admin-page.php");
    }
    else if ($_SESSION['vendor_sid']==session_id()) {
      header("location:vendor.php");
    }
    else if ($_SESSION['loading_sid']==session_id()) {
      header("location:loading-page.php");
    }
     else {
      header("location:login.php");
    }
}
