<?php
include 'includes/connect.php';

	if($_SESSION['admin_sid']==session_id())
	{
		?>

<?php
	require_once('view-comp/admin-header.php');
?>

		<div class="content-card">
	        <div class="card-body">
	        	<div align="center">
	        		<h1><b><i class="fas fa-utensils"></i> BEEP BEEP HERE COMES THE iAC BEEP</b></h1>
		    		<h3> Welcome, <?=$_SESSION['name']?></h3><br>
		    	</div>

	        	<div class="divider"></div>
         			 <!--editableTable-->
					<form class="formValidate" id="formValidate1" method="post" action="routers/user-router.php" novalidate="novalidate">
			    <div class="row">
				  	<div class="col s12 m4 l3">
				      <h2 class="header">LIST OF ALL USERS</h2>
				     </div>
			      </div>

<table class="table">
  <thead>
    <tr>
      <th>Name</th>
      <th>Username</th>
      <th>Email</th>
      <th>Contact</th>
      <th>Address</th>
      <th>Role</th>
      <th>Verified</th>
      <th>Enable</th>
      <th>Wallet</th>
      <th>Balance</th>
    </tr>
  </thead>
  <tbody>
	<?php
		$result = mysqli_query($con, "SELECT * FROM users");
		while($row = mysqli_fetch_array($result))
		{
			echo '<tr><td>'.$row["name"].'</td>';
			echo '<td>'.$row["username"].'</td>';
			echo '<td>'.$row["email"].'</td>';
			echo '<td>'.$row["contact"].'</td>';
			echo '<td>'.$row["address"].'</td>';

			echo '<td><select name="'.$row['id'].'_role">
				<option value="Administrator">Administrator</option>
				<option value="Customer"'.($row['role']=='Customer' ? 'selected' : '').'>Customer</option>
				<option value="vendor"'.($row['role']=='vendor' ? 'selected' : '').'>vendor</option>
				<option value="Loading"'.($row['role']=='Loading' ? 'selected' : '').'>Loading</option>
				</select></td>';

			echo '<td><select name="'.$row['id'].'_verified">
				<option value="1"'.($row['verified'] ? 'selected' : '').'>Verified</option>
				<option value="0"'.(!$row['verified'] ? 'selected' : '').'>Not Verified</option>
				</select></td>';
			echo '<td><select name="'.$row['id'].'_deleted">
				<option value="1"'.($row['deleted'] ? 'selected' : '').'>Disable</option>
				<option value="0"'.(!$row['deleted'] ? 'selected' : '').'>Enable</option>
				</select></td>';
					$key = $row['id'];
					$sql = mysqli_query($con,"SELECT * from wallet WHERE customer_id = $key;");
						if($row1 = mysqli_fetch_array($sql)){
							$wallet_id = $row1['id'];
							$sql1 = mysqli_query($con,"SELECT * from wallet_details WHERE wallet_id = $wallet_id;");
							if($row2 = mysqli_fetch_array($sql1)){
												$balance = $row2['balance'];
							}
						}
							echo '<td><label for="balance">Balance</label><input id="balance" name="'.$row['id'].'_balance" value="0" type="number" data-error=".errorTxt01"><div class="errorTxt01"></div></td>';
							echo '<td>'.$balance.'</td></tr>';
							
		}
?>
  </tbody>
								</table>
					        </div>
							<div class="col text-right">
					     		<button class="btn" type="submit" name="action">Modify
					       		<i class="fas fa-angle-double-right"></i>
					       		</button>
					   		</div>
					    </div>
					  </div>
					</form>

<br><br>

</div>
</div>
</div>
</body>
</html>

<?php
	}
	else
	{
		if ($_SESSION['admin_sid']==session_id()) {
			header("location:admin-page.php");
		}
		 else if($_SESSION['customer_sid']==session_id())
		{
			header("location:index.php");
		}
		else if ($_SESSION['vendor_sid']==session_id()) {
			header("location:vendor.php");
		}
		else if ($_SESSION['loading_sid']==session_id()) {
			header("location:loading-page.php");
		}
		 else {
			header("location:login.php");
		}
}
