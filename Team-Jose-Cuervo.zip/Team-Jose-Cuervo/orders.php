 <?php
include 'includes/connect.php';
include 'includes/wallet.php';

  if($_SESSION['customer_sid']==session_id())
  {
    ?>
<?php
  require_once('view-comp/user-header.php');
?>
<style type="text/css">
  .legend {
    border-left: 6px solid #178CA4;
    background-color: lightgrey;
    border-radius: 12px;
    color: black;
    font-size: 13px;    
    width: 100%;
    padding: 5px;
    margin: 2px;   
  }

  .btn {
    background-color: white; 
    color: black; 
    border: 2px solid #008CBA;
  }

  .btn:hover {
    background-color: #178CA4;
    color: white;
  }
  table {
  border-collapse: collapse;
  width: 100%;
  }

  th, td {
    padding: 8px;
    text-align: left;
    border-bottom: 1px solid #ddd;
  }

  tr:hover {
    background-color:#ADD8E6;
  }
</style>
<title>Student Page</title>
<div class="w3-main" style="margin-left:300px">
  <div class="content">
    <h2>Order History</h2>
  </div>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <div class="legend">
    <p><h4 style="text-align: center;">LEGEND</h4></p>
    <p><strong>Preparing</strong> - The Stall is preparing your order</p>
    <p><strong>Order Ready</strong> - The order is ready to be picked up</p>
    <p><strong>Order Completed</strong> - The order is finished and has been picked up</p>
    <p><strong>Cancelled by Customer</strong> - The order is cancelled and will stop being prepared.</p>
    <p><strong>Paused</strong> - The order is paused by the vendor</p>
  </div>
  
  <div>
    <br>
    <table width="98%">
      <tr>
        <th style="text-align: left;">DATE</th>
        <th style="text-align: left;">ORDER NO</th>
        <th style="text-align: left;">ITEM NAME</th>
        <th style="text-align: left;">STATUS</th>
        <th style="text-align: center;">PRICE</th>
        <th style="text-align: right;">QUANTITY</th>
        <th style="text-align: right; padding-right: 25px;">CANCEL</th>
      </tr>
      <tr>
        <?php

          if(isset($_GET['status'])){
          $status = $_GET['status'];
          echo '<div>Working?</div>';
        } else{
          $status = '%';
        }

        $sql = mysqli_query($con, "SELECT * FROM orders WHERE user_id = $user_id AND status LIKE '$status' ORDER BY order_id DESC;");
            while($row = mysqli_fetch_array($sql))
            {
              $status = $row['status'];

              $order_id = $row['order_id'];
              $sql1 = mysqli_query($con, "SELECT * FROM order_details WHERE id = $order_id;");
              
              while($row1 = mysqli_fetch_array($sql1))
              {
                $item_id = $row1['item_id'];
                $sql2 = mysqli_query($con, "SELECT * FROM items WHERE id = $item_id;");
                while($row2 = mysqli_fetch_array($sql2)){
                 $item_name = $row2['name'];

            echo '
              <td>
                <p><strong>'.$row['date'].'</strong></p>
              </td>
              <td style="text-align: left; padding-left: 15px;">
                '.$row['id'].'
              </td>
              <td>
                <p>'.$item_name.'</p> 
              </td>
              
              <td style="text-align: left;">
                <p>'.($status=='Paused' ? 'Paused <a  data-position="bottom" data-delay="50" data-tooltip="Please contact administrator for further details." class="btn-floating waves-effect waves-light tooltipped cyan">    ?</a>' : $status).'</p>'.(!empty($row['description']) ? '<p><strong>Note: </strong>'.$row['description'].'</p>' : '').'
                    <a href="#" class="secondary-content"><i class="mdi-action-grade"></i></a>
                </td>
                <td style="text-align: center;">
                   <span>Php '.$row1['total'].'</span>
                </td>
                <td style="text-align: right;">
                  <span>'.$row1['qty'].' Pieces</span>
                </td>
              <td style="text-align: right;">';
              $id = $row['order_id'];

            }
            }
                if(!preg_match('/^Cancelled/', $status)){
                  if($status != 'Delivered'){
                echo '<form action="routers/cancel-order.php" method="post">
                    <input type="hidden" value="'.$order_id.'" name="id">
                    <input type="hidden" value="Cancelled by Customer" name="status">
                    <input type="hidden" value="'.$row['payment_type'].'" name="payment_type">
                    <button class="btn" type="submit" name="action">
                    Cancel Order
                    <i class="mdi-content-clear right"></i>
                    </button>
                    </form>';
                }
                }
                echo'</td></tr>
                ';
          }
          ?>
          
     </table>      
  </div>

  </div>
</body>
</html>

<?php
  }
  else
  {
    if ($_SESSION['customer_sid']==session_id()) {
      header("location:index.php");
    }
     else if($_SESSION['admin_sid']==session_id())
    {
      header("location:admin-page.php");
    }
    else if ($_SESSION['vendor_sid']==session_id()) {
      header("location:vendor.php");
    }
    else if ($_SESSION['loading_sid']==session_id()) {
      header("location:loading-page.php");
    }
     else {
      header("location:login.php");
    }
}