<?php
include 'includes/connect.php';
include 'includes/wallet.php';
$continue=0;
$total = 0;
$payment_type = $_POST['payment_type'];
@$item_id = $_POST['item_id'];
if($_SESSION['customer_sid']==session_id())
{
		if($_POST['payment_type'] == 'wallet'){
		$_POST['cc_number'] = str_replace('-', '', $_POST['cc_number']);
		$_POST['cc_number'] = str_replace(' ', '', $_POST['cc_number']);
		$_POST['cvv_number'] = (int)str_replace('-', '', $_POST['cvv_number']);
		$sql1 = mysqli_query($con, "SELECT * FROM wallet_details where wallet_id = $wallet_id");
		while($row1 = mysqli_fetch_array($sql1)){
			$card = $row1['number'];
			$cvv = $row1['cvv'];
			if($card == $_POST['cc_number'] && $cvv==$_POST['cvv_number'])
			$continue=1;
			else
				header("location:index.php");
		}
		}
		else
			$continue=1;
}

$result = mysqli_query($con, "SELECT * FROM users where id = $user_id");
while($row = mysqli_fetch_array($result)){
	$name = $row['name'];
	$contact = $row['contact'];
}

if($continue){
?>

<?php
	require_once('view-comp/user-header.php');
?>
<style type="text/css">
	.btn {
	  display: inline-flex;
	  height: 40px;
	  width: 150px;
	  border: 2px solid #BFC0C0;
	  margin: 20px 20px 20px 20px;
	  color: black;
	  text-transform: uppercase;
	  text-decoration: none;
	  font-size: .8em;
	  letter-spacing: 1.5px;
	  align-items: center;
	  justify-content: center;
	  overflow: hidden;
	}

	span {
	  color: black;
	  text-decoration: none;
	  letter-spacing: 1px;
		}
	#button-4 {
	  position: relative;
	  overflow: hidden;
	  cursor: pointer;
	}

	#button-4 a {
	  position: relative;
	  transition: all .45s ease-Out;
	}

	#underline {
	  width: 100%;
	  height: 2.5px;
	  margin-top: 15px;
	  align-self: flex-end;
	  left: -200px;
	  background: #BFC0C0;
	  position: absolute;
	  transition: all .3s ease-Out;
	  bottom: 0;
	}

	#button-4:hover #underline {
	  left: 0;
	}
	.caption{
	  border: 1px solid black;
	}
</style>

<title>Student Page</title>
<form action="routers/order-router.php" method="post">
<div class="w3-main" style="margin-left:300px">
	<div class="content">
		<h2 class="card-title">RECEIPT</h2>
	<div>
	<?php
    echo '<table width="100%" style="text-align:left;">
    <tr>
		<th><strong>Name:</strong>
		<td>'.$name.'</td>
	<tr>
		<th><strong>Contact Number:</strong></th>
		<td>'.$contact.'</td>
	</tr>
	<tr>
		<th><strong>Payment Type:</strong></th>
		<td>'.$payment_type.'</td>
	</tr>
	</table>
	
	
	<table width="100%" style="text-align:left;">
		<tr>
			<th>Stall</th>
			<th>Item ID</th>
			<th>Food Item</th>
			<th>Quantity</th>
			<th>Price</th>
		</tr>';

		$user_id = $_SESSION['user_id'];
		$sql = "SELECT * FROM cart where user_id = '$user_id'";
		$result = $con->query($sql);
		$ctr = 0;
		if($result->num_rows > 0){
			while($row = $result->fetch_assoc()){
			    $ctr = $ctr + 1;
				$price = $row["qty"]*$row["item_price"];
				$total = $total + $price;
				$stall = $row["stall"];
				$item_id = $row["item_id"];

	echo '
		<tr>
			<th>
				<h3>'.$row["stall"].'</h5></td>
				<input type = "hidden" name = "stall'.$ctr.'" value ="'.$stall.'">
			</th>
			<td>
				<h3>'.$row["item_id"].'</h5></td>
				<input type = "hidden" name = "item_id'.$ctr.'" value = "'.$item_id.'">
			</td>
			<td>
				<h5>'.$row["item_name"].'</h5></td>
			<td>
				<span>'.$row["qty"].' Pieces</span>
				<input type="hidden" name="qty'.$ctr.'"  min="0" required value="'.$row["qty"].'"/>
			</td>
			<td>
				<span>Php '.$price.'</span>
				<input type="hidden" name="price'.$ctr.'"  min="0" required value="'.$price.'"/>
			</td>
		</tr>';
		}
		echo '<input type="hidden" name="ctr"  min="0" required value="'.$ctr.'"/>
		<tr>
		<h4 style="text-align:right; padding-right: 15px;"><strong>Total: Php '.$total.'</strong></h4>
		<input type="hidden" name="total"  min="0" required value="'.$total.'"/>
	</tr><br></table>';
	}
	
	if(!empty($_POST['description']))
		echo '<li class="collection-item avatar"><p><strong>Note: </strong>'.htmlspecialchars($_POST['description']).'</p></li>';
	if($_POST['payment_type'] == 'Wallet'){
		echo '<h6><strong>Current Balance: '.$balance.'</h6>';
		echo '<h6>Balance after purchase: '.($balance - $total).'</h6></strong>';
	}
?>


<input type="hidden" name="payment_type" value="<?php echo $_POST['payment_type'];?>">
<?php if (isset($_POST['description'])) { echo'<input type="hidden" name="description" value="'.htmlspecialchars($_POST['description']).'">';}?>
<?php if($_POST['payment_type'] == 'Wallet') echo '<input type="hidden" name="balance" value="<?php echo ($balance-$total);?>">'; ?>
<input type="hidden" name="total" value="<?php echo $total;?>">

<div class="input-field col s12">
<button class="btn" id="button-4" type="submit" name="action" <?php if($_POST['payment_type'] == 'Wallet') {if ($balance-$total < 0) {echo 'disabled'; }}?>>
	<div id="underline"></div>
    Confirm Order
</button>
	</div>
	</table >
	</form>
	</body>
</html>
<?php
	}
	else
	{
		if ($_SESSION['customer_sid']==session_id()) {
			header("location:index.php");
		}
		 else if($_SESSION['admin_sid']==session_id())
		{
			header("location:admin-page.php");
		}
		else if ($_SESSION['vendor_sid']==session_id()) {
			header("location:vendor.php");
		}
		else if ($_SESSION['loading_sid']==session_id()) {
			header("location:loading-page.php");
		}
		 else {
			header("location:login.php");
		}
}
