<?php
include 'includes/connect.php';
include 'includes/wallet.php';

	if($_SESSION['customer_sid']==session_id())
	{
		?>

<?php
	require_once('view-comp/user-header.php');
?>

<!-- !PAGE CONTENT! -->
<title>Student Page</title>
<div class="w3-main" style="margin-left:300px">

  <!-- Header -->
  <header id="portfolio">
    <a href="#"><img src="/w3images/avatar_g2.jpg" style="width:65px;" class="w3-circle w3-right w3-margin w3-hide-large w3-hover-opacity"></a>
    <span class="w3-button w3-hide-large w3-xxlarge w3-hover-text-grey" onclick="w3_open()"><i class="fa fa-bars"></i></span>
    <div class="w3-container">
    	<h2><b>BEEP BEEP here comes the iAC BEEP</b></h2>
    	<h4>Order Foods from these Stalls</h4>
    	<h5 style="text-align: right;">Balance: Php <?php echo $balance;?></h5>
    </div>	
 
  
  <div class="w3-row-padding">
    <div class="w3-third w3-container w3-margin-bottom">
    	<a href="potato-corner.php">
	    <img  src="images/potato-corner.png" alt="potato-corner" style="width:100%" class="w3-hover-opacity">
	    <div class="w3-container w3-white">
	        <p><b>Potato corner</b></p>
	        <p>Snacks, Kiosk, Asian</p>
	    </div>
    </div>
    <div class="w3-third w3-container w3-margin-bottom">
    	<a href="kitchen-city.php">
      	<img src="images/kitchen-city.jpg"  alt="kitchen-city" style="width:100%" class="w3-hover-opacity">
      	<div class="w3-container w3-white">
        	<p><b>Kitchen City</b></p> 
        	<p>pagkain,</p>       
      	</div>
    </div>
    <div class="w3-third w3-container">
    	<a href="master-siomai.php">
      	<img src="images/master-siomai.png" alt="master-siomai" style="width:100%" class="w3-hover-opacity">
      	<div class="w3-container w3-white">
        <p><b>Master Siomai</b></p>
        <p>Kiosk, Dim Sum, Chinese</p>
      </div>
    </div>
  </div>
  
  </div>
  </body>
</html>

<?php
	}
	else
	{
		if ($_SESSION['customer_sid']==session_id()) {
			header("location:index.php");
		}
		 else if($_SESSION['admin_sid']==session_id())
		{
			header("location:admin-page.php");		
		}
		else if ($_SESSION['vendor_sid']==session_id()) {
			header("location:vendor.php");
		}
		else if ($_SESSION['loading_sid']==session_id()) {
			header("location:loading-page.php");
		}
		 else {
			header("location:login.php");
		}	
}