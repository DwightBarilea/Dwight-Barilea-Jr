<?php
include 'includes/connect.php';
include 'includes/wallet.php';

	if($_SESSION['customer_sid']==session_id())
	{
		?>
<style type="text/css">
	@import 'https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300';

.btn {
  display: inline-flex;
  height: 40px;
  width: 150px;
  border: 2px solid #BFC0C0;
  margin: 20px 20px 20px 20px;
  color: #BFC0C0;
  text-transform: uppercase;
  text-decoration: none;
  font-size: .8em;
  letter-spacing: 1.5px;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

span {
  color: black;
  text-decoration: none;
  letter-spacing: 1px;
}

#button-2 {
  position: relative;
  overflow: hidden;
  cursor: pointer;
}

#button-2 a {
  position: relative;
  transition: all .35s ease-Out;
}

#slide {
  width: 100%;
  height: 100%;
  left: -200px;
  background: #8CBDB9;
  position: absolute;
  transition: all .35s ease-Out;
  bottom: 0;
}

#button-2:hover #slide {
  left: 0;
}

#button-2:hover a {
  color: #8CBDB9;
}
img {
	border-radius: 50%;
}
.header {
  padding: 60px;
  text-align: center;
  background-color: #8CBDB9;
  color: white;
  font-size: 30px;
  width: 100%;
}

</style>
<?php
	require_once('view-comp/user-header.php');
	$user_id = $_SESSION['customer_sid'];
?>
<title>Student Page</title>
<div class="w3-main" style="margin-left:300px">
		<div class="content">
			<div>
				<button class="btn">
					<a href="index.php"><span><i class="fas fa-angle-left"></i> Go back</span> </a>
				</button>	
				<button class="btn" style="float: right;">
					<a href="cart.php"><span>VIEW CART<i class="fas fa-angle-right f"></i></span> </a>
				</button>				
			</div>
			<div class="header">
				<h2><img border="0" alt="potato-corner" src="images/potato-corner.png" width="150" height="150"> POTATO CORNER</h2>
			</div>				
		</div>			

			<?php
			if(isset($_SESSION['Item_cart_added_message'])){
				echo $_SESSION['Item_cart_added_message'];
				unset($_SESSION['Item_cart_added_message']);
			}
			?><br>
			<table>

			<form method="post" action="routers/add-cart.php">
				<table width="100%">
					<tr>
						<th style="text-align: left;">Name</th>
						<th style="text-align: center;">Item Price/Piece</th>
            			<th style="text-align: center;">Quantity</th>
					</tr>

					<!-- // stall name lagay mo para makuha sa next page same with user id -->
					<input type="hidden" name="stall_name" value="PotatoCorner">
					<input type="hidden" name="user_id" value="<?php echo $user_id;?>">
				<?php
				$result = mysqli_query($con, "SELECT * FROM items where not deleted AND
					stall = 'PotatoCorner'");
					$ctr = 0;
				while($row = mysqli_fetch_array($result))
				{
					$ctr = $ctr + 1;
					echo '<tr>
							<td>
								'.$row["name"].'
								<input type="hidden" name="id'.$ctr.'" value="'.$row["id"].'">
								<input type="hidden" name="name'.$ctr.'" value="'.$row["name"].'">
							</td>
							<td>
							<center>
							Php. '.$row["price"].'
							<input type="hidden" name="price'.$ctr.'" value="'.$row["price"].'">
							</center>
							</td>';
					  echo '<td>
					  <center>
								<div class="input-field col s12">
									<label for="qty'.$ctr.'" class=""> </label>
									<input id="qty'.$ctr.'" name="qty'.$ctr.'" type="number" min="0" required style="text-align:center;" value=0 ></center>';
				}
				?>
				<!-- sending the couter to the other page to know how many items there is -->
				<input type="hidden" name="ctr" value="<?php echo $ctr;?>">
				</table>

					<br>

			  <div class="input-field col s12">
              	<i class="mdi-editor-mode-edit prefix"></i>
             	 <textarea id="description" name="description" class="materialize-textarea"></textarea>
              		<label for="description" class="">Any note(optional)</label>
			  </div>

				<div class="input-field col s12">

					<button class="btn" id="button-2" name="action">					    
					    <span>Add to cart <i class="fas fa-angle-right f"></i></span>			
					</button>

				</div>

			</form>
		</table>
		</div>
	</body>
</html>

<?php
	}
	else
	{
		if ($_SESSION['customer_sid']==session_id()) {
			header("location:index.php");
		}
		 else if($_SESSION['admin_sid']==session_id())
		{
			header("location:admin-page.php");
		}
		else if ($_SESSION['vendor_sid']==session_id()) {
			header("location:vendor.php");
		}
		else if ($_SESSION['loading_sid']==session_id()) {
			header("location:loading-page.php");
		}
		 else {
			header("location:login.php");
		}
}

?>
