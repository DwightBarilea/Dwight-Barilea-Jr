<?php
include 'includes/connect.php';


	if($_SESSION['vendor_sid']==session_id())
	{
		?>
<?php
	require_once('view-comp/vendor-header.php');
?>

<body>
<ul>
<?php
$sql = "SELECT * FROM orders WHERE status LIKE 'Preparing';";
$result = mysqli_query($con,$sql);

while($row = mysqli_fetch_array($result)){
    $order_id = $row['id'];
	$result1 = mysqli_query($con, "SELECT * FROM order_details WHERE order_id = $order_id;");

    echo '<li>
     <p>'.$row['id'].'</p>
     <p>'.$row['user_id'].'</p> </li>';
     while($row1 = mysqli_fetch_array($result1))
	{

		// echo '<li>
		// 	<p>'.$row1['order_id'].'</p>
		// 	</li>';

		$item_id = $row1['item_id'];
		$result2 = mysqli_query($con, "SELECT * FROM items WHERE id = $item_id;");
		while($row2 = mysqli_fetch_array($result2))
		{
			echo '
    		 		<p>'.$row2['name'].'</p>
    		 	 ';
		}
	}
    echo '
    
     <p>'.$row['date'].'</p>
     <p>'.$row['payment_type'].'</p>
     <p>'.$row['total'].'</p>
     <p>'.$row['status'].'</p>
     <p>'.$row['deleted'].'</p>
     ';


}


?>

</body>
</html>


<?php
	}
	else
	{
		if ($_SESSION['vendor_sid']==session_id()) {
			header("location:vendor.php");
		}
		 else if($_SESSION['customer_sid']==session_id())
		{
			header("location:index.php");
		}
		else if ($_SESSION['admin_sid']==session_id()) {
			header("location:admin-page.php");
		}
		 else {
			header("location:login.php");
		}
}
