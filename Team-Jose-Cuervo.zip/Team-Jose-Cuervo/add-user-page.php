<?php
include 'includes/connect.php';


	if($_SESSION['admin_sid']==session_id())
	{
		?>

<?php
	require_once('view-comp/admin-header.php');
?>

		<div class="content-card">
	        <div class="card-body">
	        	<div align="center">
	        		<h1><b><i class="fas fa-utensils"></i> BEEP BEEP HERE COMES THE iAC BEEP</b></h1>
		    		<h3> Welcome, <?=$_SESSION['name']?></h3><br>
		    	</div>
		    	
	        	<div class="divider"></div>
         			 <!--editableTable-->
					<form class="formValidate" id="formValidate1" method="post" action="routers/add-users.php" novalidate="novalidate">
			    <div class="row">
				  	
			      </div>



<div class="col s12 m4 l3"><h2 class="header">ADD USER:</h2></div>

<form class="formValidate" id="formValidate" method="post" action="routers/add-users.php" novalidate="novalidate">

<div class="container center_div"> 
  <div class="form-row">
  	<?php  
    	echo'<div class="form-group col-md-6">
       		<label for="username">Username: </label>
       		<input class="form-control" id="username" name="username" type="text" data-error=".errorTxt02">
       		<div class="errorTxt02"></div>
    		</div>';
     	echo'<div class="form-group col-md-6">
       	  	<label for="password">Password: </label>
       	  	<input class="form-control id="password" name="password" type="password" data-error=".errorTxt03">
       	  	<div class="errorTxt03"></div>
   			</div>';
   		echo'<div class="form-group col-md-6">
       	  	<label for="name">Name: </label>
       	  	<input class="form-control id="name" name="name" type="text" data-error=".errorTxt04">
       	  	<div class="errorTxt04"></div>
   			</div>';
   		echo'<div class="form-group col-md-6">
       	  	<label for="email">Email: </label>
       	  	<input class="form-control id="email" name="email" type="email">
   			</div>';
   		echo'<div class="form-group col-md-6">
       	  	<label for="contact">Phone Number: </label>
       	  	<input class="form-control id="contact" name="contact" type="number" data-error=".errorTxt05">
       	  	<div class="errorTxt05"></div>
   			</div>';
   		echo'<div class="form-group col-md-6">
       	  	<label for="address">Address: </label>
       	  	<input class="form-control id="address" name="address" type="text" data-error=".errorTxt06">
       	  	<div class="errorTxt06"></div>
   			</div>';
   		echo '<div class="form-group col-md-10">
   			<label for="role">Role: </label>
   				<select class="form-control" name="role">
					<option value="Administrator">Administrator</option>
					<option value="Customer" selected>Customer</option>
					<option value="Loading">Loading</option>
					<option value="vendor">vendor</option>
				</select>
			</div>';
   		echo '<div class="form-group col-md-10">
   			<label for="role">Verification: </label>
   				<select class="form-control" name="verified">
					<option value="1">Verified</option>
					<option value="0" selected>Not Verified</option>
				</select>
			</div>';
		echo '<div class="form-group col-md-10">
   			<label for="role">Enable: </label>
   				<select class="form-control" name="deleted">
					<option value="1">Disable</option>
					<option value="0" selected>Enable</option>
				</select>
			</div>';
  ?>
  </div>
  <div class="col text-right">
	  <button class="btn" type="submit" name="action">Add
	    	<i class="fas fa-angle-double-right"></i>
	  	</button>
  </div>
</form>
<div class="col text-left">
	
	<button class="btn"><i class="fas fa-angle-double-left"></i> BACK</button>
</div>

</div>
</div>
</div>
</body>
</html>

<?php
	}
	else
	{
		if ($_SESSION['admin_sid']==session_id()) {
			header("location:admin-page.php");
		}
		 else if($_SESSION['customer_sid']==session_id())
		{
			header("location:index.php");
		}
		else if ($_SESSION['vendor_sid']==session_id()) {
			header("location:vendor.php");
		}
		else if ($_SESSION['loading_sid']==session_id()) {
			header("location:loading-page.php");
		}
		 else {
			header("location:login.php");
		}
}
?>
