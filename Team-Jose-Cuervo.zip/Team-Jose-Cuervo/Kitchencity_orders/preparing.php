<?php
include 'includes/connect.php';


	if($_SESSION['vendor_sid']==session_id())
	{
?>
<?php
	require_once('KitchenCity-header.php');
?>
<style type="text/css">
    .order-items{
		text-align: center;
	}
	.order-item{
		width: 30%;
		height: 500px;
		background-color: #F9F7F0;
		margin: 10px;
		padding: 10px;
		border-radius: 5px;
		border: 1px solid black;
		color: #072A40;
		overflow: auto;
		display: inline-block;
		font-size: 14px;

	}
	.order-number{
		text-align: center;
		font-weight: bold;
		font-size: 18px;
		width: 100%;
	}

</style>

<h2>PREPARING</h2>

<table class="tbl">

<?php

	if(isset($_GET['status'])){
		$status = $_GET['status'];
	} else{
		$status = '%';
	}
	$sql = mysqli_query($con, "SELECT * FROM orders WHERE status LIKE 'Preparing';");
	echo '<div class="row">
  <div>';
	while($row = mysqli_fetch_array($sql)) {
		$order_id = $row['order_id'];
		$user_id = $row['user_id'];
		$sql1 = mysqli_query($con, "SELECT * FROM order_details WHERE id = $order_id AND stall = 'KitchenCity';");
		$status = $row['status'];
		$deleted = $row['deleted'];
		while($row1 = mysqli_fetch_array($sql1)){
		echo '<div class="order-item">
				<div class="order-number">
					Order No. '.$row1['id'].
				'</div>
				<div class="store-item-desc">
					<p><strong>Date:</strong> '.$row['date'].'</p>
				</div>
				<div class="order-item-details">
					<p><strong>Payment Type:</strong> '.$row['payment_type'].'</p>
			    	<a href="#" class="secondary-content"><i class="mdi-action-grade"></i></a>
				</div>


			';



		$sql3 = mysqli_query($con, "SELECT * FROM users WHERE id = $user_id;");
		while($row3 = mysqli_fetch_array($sql3)) {
			echo '
      <div class="row">
				<p><strong>Name: </strong>'.$row3['name'].'</p>
					'.($row3['contact'] == '' ? '' : '<p><strong>Contact: </strong>'.$row3['contact'].'</p>').'
					'.($row3['email'] == '' ? '' : '<p><strong>Email: </strong>'.$row3['email'].'</p>').'
					'.(!empty($row['description']) ? '<p><strong>Note: </strong>'.$row['description'].'</p>' : '').'
        ';
			}
 				$item_id = $row1['item_id'];
				$sql2 = mysqli_query($con, "SELECT * FROM items WHERE id = $item_id;");
				while($row2 = mysqli_fetch_array($sql2)){
				$item_name = $row2['name'];

				echo '
        <div class="row">
        	<div class="col s7">
          	<p class="collections-title"><strong>ORDER: </strong><br>'.$item_name.'</p>
          	<p>'.$row1['qty'].' Pieces</p>
          </div>
          <div class="col s3">
          	<span>Php '.$row2['price'].'</span>
          </div>
        </div>
      	';
			}
			echo'<strong>Total: Php '.$row['total'].'</strong>
        </div> <p><strong>Status:</strong> '.($deleted ? $status : '</p>

				<form method="post" action="routers/edit-orders.php">
				<input type="hidden" value="'.$row['id'].'" name="id">

				<select name="status">
					<option value="Preparing" '.($status=='Preparing' ? 'Preparing' : '').'>Preparing</option>
					<option value="Order Ready" '.($status=='Order Ready' ? 'selected' : '').'>Order Ready</option>
					<option value="Orders Completed" '.($status=='Orders Completed' ? 'selected' : '').'>Orders Completed</option>
					<option value="Cancelled by Customer" '.($status=='Cancelled by Customer' ? 'selected' : '').'>Cancelled by Customer</option>
					<option value="Paused" '.($status=='Paused' ? 'selected' : '').'>Paused</option>
				</select>

					').'</p>';
				if(!$deleted){
					echo '<button class="btn waves-effect waves-light right submit" type="submit" name="action">Change Status
          	<i class="mdi-content-clear right"></i>
								</button>
				</form>';
				}
				echo'</div></div></div>';
			}
			}
		?>

</div>
</div>
</div>
</div>

</body>
</html>



<?php
	}
	else
	{
		if ($_SESSION['vendor_sid']==session_id()) {
			header("location:vendor.php");
		}
		 else if($_SESSION['customer_sid']==session_id())
		{
			header("location:index.php");
		}
		else if ($_SESSION['admin_sid']==session_id()) {
			header("location:admin-page.php");
		}
		 else {
			header("location:login.php");
		}
}
