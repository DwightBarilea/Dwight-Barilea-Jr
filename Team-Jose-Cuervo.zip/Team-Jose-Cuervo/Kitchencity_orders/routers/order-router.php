<?php
include '../includes/connect.php';
include '../includes/wallet.php';

$total = $_POST['total'];
$payment_type = $_POST['payment_type'];
$ctr = $_POST['ctr'];
$convert = (int)$ctr;
$idName = "item_id";
$QtyName = "qty";
$stall = "stall";
$price = "price";
$id = "";
$user_id = $_SESSION['user_id'];
echo $convert;

for($i = $convert;$i > 0; $i--){
	$idTagName = $idName . $i;
	$qtyName = $QtyName . $i;
	$stallName =  $stall . $i;
	$priceName = $price . $i;

	echo 'this is a '.$i.'<br />';
	echo 'this is a '.$idTagName.'<br />';
	echo 'this is a '.$qtyName.'<br />';
	echo 'this is a '.$stallName.'<br />';
	echo 'this is a '.$priceName.'<br />';

	$item_id_value = $_POST[$idTagName];
	$item_qty_value = $_POST[$qtyName];
	$stall_value = $_POST[$stallName];
	$price_value = $_POST[$priceName];

	echo 'this is a '.$item_id_value.'<br />';
	echo 'this is a '.$item_qty_value.'<br />';
	echo 'this is a '.$stall_value.'<br />';
	echo 'this is a '.$price_value.'<br />';



	$query = 'INSERT INTO order_details (user_id,item_id,stall,qty, total) VALUES (?,?,?,?,?)';
	$stmt = $con->prepare($query);
	$stmt->bind_param("iisii", $user_id,$item_id_value,$stall_value,$item_qty_value,$total);
	$stmt->execute();

	$order_id = mysqli_insert_id($con);
	echo "<br /> id: ".$order_id;

	$query2 = 'INSERT INTO orders (user_id,order_id,payment_type,total) VALUES (?,?,?,?)';
	$stmt2 = $con->prepare($query2);
	$stmt2->bind_param("iisi", $user_id,$order_id,$payment_type,$total);
	$stmt2->execute();

	if($_POST['payment_type'] == 'Wallet'){
		$balance = $balance - $total;
		$sql = "UPDATE wallet_details SET balance = '$balance' WHERE wallet_id = '$wallet_id';";
		$con->query($sql) === TRUE;
	}

}
header("location: ../orders.php");


?>
