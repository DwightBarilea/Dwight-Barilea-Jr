<?php
include '../includes/connect.php';

$stall = $_POST['stall'];
$name = $_POST['name'];
$price = $_POST['price'];
$sql = "INSERT INTO items (name, price,stall) VALUES ('$name', '$price',  '$stall')";
$con->query($sql);

 if($stall == "PotatoCorner"){
      header("location: ../PotatoCorner.php");
    }elseif ($stall == "MasterSiomai") {
      header("location: ../MasterSiomai.php");
    }elseif ($stall == "KitchenCity") {
      header("location: ../KitchenCity.php");
    }
?>
