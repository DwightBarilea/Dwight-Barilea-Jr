<?php
  include '../includes/connect.php';
  $stall_name = $_POST['stall_name'];
  $user_id = $_SESSION['user_id'];
  $ctr = $_POST['ctr'];

  echo "user id ".$user_id;//to check if we were able to get the data
  echo "<br />ctr = ".$ctr;//to check if we were able to get the data
  //wag ka malito pre sa counter
  // para mas madali kaysa isa isahin yung counter is galing sa previous page

    //to get the value of quantity we need to do string concatination
    //based on the previous page we named the input tag og quantity according to qty$row["name"]
    $i = $ctr; //putting values of ctr to i to make sure only the index changes
    while($i>=1){
      $idName = "id".$i;//mga pre etong code na toh pag add lang para makuha name ng input tag sa previous page
      $priceName = "price".$i;//mga pre etong code na toh pag add lang para makuha name ng input tag sa previous page
      $qtyName = "qty".$i; // what this does it combines the 2 strings together
      $itemName = "name".$i; //eto para makuha yung name
      //now we will get the post data from the previous page
      $Item_name = $_POST[$itemName];
      $id = $_POST[$idName];
      $price = $_POST[$priceName];
      $qty = $_POST[$qtyName];
      echo '<br />This will be inserted to db '.$id.' '.$price.' '.$qty.' '.$Item_name;
      if($qty>0){ //para pag zero di na aadd sa cart
        $sql = "INSERT INTO cart (item_name, user_id, item_id, qty, item_price, stall) VALUES ('$Item_name','$user_id', '$id', '$qty', '$price', '$stall_name')";
        $con->query($sql);
        $_SESSION['Item_cart_added_message'] = "<center><h1>ITEM ADDED</h1></center>";
      }
      $i = $i - 1;
    }
    if($stall_name == "PotatoCorner"){
      header("location: ../potato-corner.php");
    }elseif ($stall_name == "MasterSiomai") {
      header("location: ../master-siomai.php");
    }elseif ($stall_name == "KitchenCity") {
      header("location: ../kitchen-city.php");
    }

?>
