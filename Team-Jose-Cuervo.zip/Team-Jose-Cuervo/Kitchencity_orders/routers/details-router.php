<?php
include '../includes/connect.php';
$user_id = $_SESSION['user_id'];

$password =  htmlspecialchars($_POST['password']);

$sql = "UPDATE users SET password='$password' WHERE id = $user_id;";
if($con->query($sql)==true){
	$_SESSION['name'] = $name;
}
header("location: ../profile.php");
?>
