<?php
include '../includes/connect.php';

$ctr = $_POST['ctr'];
$convert = (int)$ctr;
$idName = "id";
$QtyName = "qty";
$btn = "productQtyBtn";
$id = "";
$user_id = $_SESSION['user_id'];
echo $convert;
//SWEET CHILD OF MINEEEE
for($i = $convert;$i > 0; $i--){
  $idTagName = $idName . $i;  //this to get row id
  $qtyName = $QtyName . $i; //this to get productQty
  $btnName =  $btn . $i; //this btn update
  echo 'this is a '.$i.'<br />';
  echo 'this is the btn '.$btnName.'<br />';
  if (isset($_POST[$i])) {
    $id = $_POST[$idTagName];
    echo $id;
    $sql = "DELETE FROM cart WHERE id = '$id' and user_id = '$user_id'";
    if (mysqli_query($con, $sql)) {
      	$_SESSION['message'] = '<h3 class="center-text">Item Removed from Cart</h3>';
    } else {
      $_SESSION['message'] = '<h3 class="center-text">Unable to remove item from Cart</h3>';
    }
    mysqli_close($con);
    header('location: ../cart.php');
  }
  else if(isset($_POST[$btnName])){


    $id = $_POST[$idTagName];
    $qty = $_POST[$qtyName];

    // session_start();
    $sql = "UPDATE cart SET qty='$qty' WHERE id = '$id' and user_id = '$user_id'";
    if (mysqli_query($con, $sql)) {
        $_SESSION['message'] = '<h3 class="center-text">Item Updated from Cart</h3>';
    } else {
      $_SESSION['message'] = '<h3 class="center-text">Unable to Update item from Cart ' . mysqli_error($con).'</h3>';
    }
    mysqli_close($con);
    header('location: ../cart.php');

    echo $id;
    echo $qty;
  }
}
 ?>
