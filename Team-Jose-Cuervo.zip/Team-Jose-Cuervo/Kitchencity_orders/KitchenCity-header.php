<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Vendor Page</title>
	<link href="css/vendor-style.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	<link href='https://fonts.googleapis.com/css?family=Amiko' rel='stylesheet'>

	<!-- JAVASCRIPT -->
    <script type="text/javascript" src="js/function.js"></script>

</head>

<body class="loggedin">

		<div class="navbar">
			<div class="left-nav">

         	 <h1><i class="fas fa-utensils"></i> BEEP BEEP BEEP HERE COMES THE iAC BEEP!</h1>

			</div>
			<div class="right-nav">
				<a href="../../Team-Jose-Cuervo/KitchenCity.php">Food Menu</a>

				<div class="dropdown">

				  	<button class="dropbtn" onclick="myFunction()">Orders</button>
					<div class="dropdown-content" id="myDropdown">
					   	<div class="collapsible-body">
              	<ul>
									<li><a href="all-orders.php">All Orders</a></li>
									<li><a href="preparing.php">Preparing</a></li>
									<li><a href="order-ready.php">Order Ready</a></li>
									<li><a href="order-completed.php">Orders Completed</a></li>
									<li><a href="cancelled-by-the-customer.php">Cancelled by Customer</a></li>
									<li><a href="paused.php">Paused</a></li>
              	</ul>
            	</div>
					 </div>
				</div>
				<a href="../../Team-Jose-Cuervo/routers/logout.php">Logout</a>
			</div>
		</div>
		<div class="name">
			<h4>Welcome back, <?=$_SESSION['name']?>!</h4><br>
		</div>
