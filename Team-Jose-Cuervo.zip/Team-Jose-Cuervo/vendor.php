<?php
	include 'includes/connect.php';

	if($_SESSION['vendor_sid']==session_id())
	{
?>

<?php
	require_once('view-comp/vendor-header.php');
?>

		<div class="header-content">
			<h1 class="header">Food Menu</h1>
		</div>

		<div class="content">
			<h2 class="header">EDIT FOOD</h2>

			<form method="post" action="routers/menu-router.php">
				<table>
					<tr>
						<th>Stall</th>
						<th>Name</th>
						<th>Item Price per Piece</th>
						<th>Available</th>
					</tr>
					<?php
						$result = mysqli_query($con, "SELECT * FROM items");
						while($row = mysqli_fetch_array($result))
						{
							echo '<tr>
									<td>
										<div class="input-field col s12">
											<strong><input value="'.$row["stall"].'" id="'.$row["id"].'_stall" name="'.$row['id'].'_stall" type="text" data-error=".errorTxt'.$row["id"].'"><div class="errorTxt'.$row["id"].'"></strong>
										</div>
									</td>
									<td>
										<div class="input-field col s12">
											<strong><input value="'.$row["name"].'" id="'.$row["id"].'_name" name="'.$row['id'].'_name" type="text" data-error=".errorTxt'.$row["id"].'"><div class="errorTxt'.$row["id"].'"></strong>
										</div>
									</td>
									<td>
								<div class="input-field col s12 ">
							<label for="'.$row["id"].'_price">Price </label>';
							echo '<input value="'.$row["price"].'" id="'.$row["id"].'_price" name="'.$row['id'].'_price" type="text" data-error=".errorTxt'.$row["id"].'"><div class="errorTxt'.$row["id"].'"></div></td>';
							echo '<td>';
							if($row['deleted'] == 0){
								$text1 = 'selected';
								$text2 = '';
							}
							else{
								$text1 = '';
								$text2 = 'selected';
							}
							echo '<select name="'.$row['id'].'_hide">
		                      <option value="1"'.$text1.'>Available</option>
		                      <option value="2"'.$text2.'>Not Available</option>
		                    </select></td></tr>';
						}

					?>

				</table>
				<br>
				<div class="input-field col s12">
					<button class="btn" type="submit" name="action">MODIFY
					<i class="fas fa-angle-double-right"></i>
					</button>
				</div>
			</form>
		</div>

		<div class="content">
			<br><br>
			<h2 class="header">Add Items</h2>

			<form method="post" action="routers/add-item.php">
				<table>
					<tr>
						<th>Stall</th>
						<th>Name</th>
						<th>Item Price per Piece</th>
					</tr>

					<?php
					echo '<tr>
						<td>
							<div class="input-field col s12">
								<input id="stall" name="stall" type="text" data-error=".errorTxt01">
								<div class="errorTxt01"></div>
							</td>
							<td>
								<div class="input-field col s12">
									<input id="name" name="name" type="text" data-error=".errorTxt01">
									<div class="errorTxt01"></div>
							</td>';
					echo '<td><div class="input-field col s12 "><label for="price" class="">Price </label>';
					echo '<input id="price" name="price" type="text" data-error=".errorTxt02"><div class="errorTxt02"></div></td>';
					echo '<td></tr>';
				?>
				</table>
				<br>
				<div class="input-field col s12">
					<button class="btn" type="submit" name="action">ADD
					<i class="fas fa-angle-double-right"></i>
					</button>
				</div>
			</form>
		</div>
	</body>
</html>


<?php
	}
	else
	{
		if ($_SESSION['vendor_sid']==session_id()) {
			header("location:vendor-page.php");
		}
		 else if($_SESSION['customer_sid']==session_id())
		{
			header("location:index.php");
		}
		else if ($_SESSION['admin_sid']==session_id()) {
			header("location:admin-page.php");
		}
		else if ($_SESSION['loading_sid']==session_id()) {
			header("location:loading-page.php");
		}
		 else {
			header("location:login.php");
		}
}
