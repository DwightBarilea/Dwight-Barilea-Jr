<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Vendor Page</title>
	<link href="css/vendor-style.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	<link href='https://fonts.googleapis.com/css?family=Amiko' rel='stylesheet'>

	<!-- JAVASCRIPT -->
    <script type="text/javascript" src="js/function.js"></script>

</head>

<body class="loggedin">

		<div class="navbar">
			<div class="left-nav">

         	 <h1><i class="fas fa-utensils"></i> BEEP BEEP BEEP HERE COMES THE iAC BEEP!</h1>

			</div>
			<div class="right-nav">
				<a href="PotatoCorner.php" >Food Menu</a>

				<div class="dropdown">

				  	<button class="dropbtn" onclick="myFunction()"> Orders</button>
					<div class="dropdown-content" id="myDropdown">
					   	<div class="collapsible-body">
              	<ul>
									<li><a href="Kitchencity_orders/all-orders.php">All Orders</a></li>
									<li><a href="Kitchencity_orders/preparing.php">Preparing</a></li>
									<li><a href="Kitchencity_orders/order-ready.php">Order Ready</a></li>
									<li><a href="Kitchencity_orders/order-completed.php">Orders Completed</a></li>
									<li><a href="Kitchencity_orders/cancelled-by-the-customer.php">Cancelled by Customer</a></li>
									<li><a href="Kitchencity_orders/paused.php">Paused</a></li>
              	</ul>
            	</div>
					 </div>
				</div>
				<a href="routers/logout.php">Logout</a>
			</div>
		</div>
		<div class="name">
			<h4>Welcome back, <?=$_SESSION['name']?>!</h4>
			<div style="float: right; padding-right: 5px;">
				<?php
					$sql = mysqli_query($con, "SELECT * FROM wallet_details WHERE id='6'");
					if($row1 = mysqli_fetch_array($sql))
					{
						echo'
							<h5>Balance: '.$row1["balance"].'</h5>';
					}
				?>
			</div>	
		</div>
		

