<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">

		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="css/loading-style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
    	<link href="https://fonts.googleapis.com/css?family=Chivo:300,700|Playfair+Display:700i" rel="stylesheet">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
		

		<!--Bootstrap-->
    	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
     <link href="https://fonts.googleapis.com/css?family=Cardo:400,700|Oswald" rel="stylesheet">

	</head>

<!------ NAVIGATION STARTS ------>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
#mySidenav a {
  position: absolute;
  right: -80px;
  transition: 0.3s;
  padding: 15px;
  width: 100px;
  text-decoration: none;
  font-size: 20px;
  color: white;
  border-radius: 3px;
}

#mySidenav a:hover {
  right: 0;
}

#hello {
	top: 20px;
	background-color: #18B7BE;
}
#logout {
  top: 160px;
  background-color: #072A40;

}
body {
 font-family: 'Cardo', serif; 
 margin: 5px;
}

h1 {
 font-family: 'Oswald', sans-serif;
 text-transform: uppercase;
}

</style>
</head>
<body>

<div id="mySidenav" class="sidenav"> 
	<a href="" id="hello"> Welcome, <?=$_SESSION['name']?>
	<a href="routers/logout.php" id="logout" >
	    <i class="fa fa-sign-in" aria-hidden="true" ></i> Logout
	</a> 
</div>