<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/admin-style.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
      <link href="https://fonts.googleapis.com/css?family=Chivo:300,700|Playfair+Display:700i" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">

    <!--Bootstrap-->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
      <link href="https://fonts.googleapis.com/css?family=Cardo:400,700|Oswald" rel="stylesheet">



<!------ NAVIGATION STARTS ------>
<style>
#mySidenav a {
  position: absolute;
  right: -90px;
  transition: 0.3s;
  padding: 15px;
  width: 120px;
  text-decoration: none;
  font-size: 17px;
  color: white;
  border-radius: 3px;
}

#mySidenav a:hover {
  right: 0;
}

#mySidenav2 a {
  position: absolute;
  right: -80px;
  transition: 0.3s;
  padding: 15px;
  width: 100px;
  text-decoration: none;
  font-size: 20px;
  color: white;
  border-radius: 3px;
}

#mySidenav2 a:hover {
  right: 0;
}

#purge {
  top: 20px;
  background-color: #072A40;
}
#logout {
  top: 120px;
  background-color: #072A40;
}

#Admin_Page {
  top: 20px;
  background-color: #18B7BE;
}

#add_user {
  top: 120px;
  background-color: #18B7BE;
}


body {
 font-family: 'Cardo', serif;
 margin: 5px;
}

h1 {
 font-family: 'Oswald', sans-serif;
 text-transform: uppercase;
}

</style>
</head>
<body>

<div id="mySidenav" class="sidenav">  
    <a href="admin-page.php" id="Admin_Page" >
      <i class="fa fa-sign-in" aria-hidden="true" ></i> Admin Page
  </a>
  <a href="add-user-page.php" id="add_user" >
      <i class="fa fa-sign-in" aria-hidden="true" ></i> Add User
  </a>
</div>

<div id="mySidenav2" class="sidenav2">

  <a href="routers/logout.php" id="logout" >
      <i class="fa fa-sign-in" aria-hidden="true" ></i> Logout
  </a>
  <a href="routers/delete-all.php" id = "purge">
    <i class="fa fa-sign-in" aria-hidden="true" ></i> Purge Database
  </a>
</div>  


