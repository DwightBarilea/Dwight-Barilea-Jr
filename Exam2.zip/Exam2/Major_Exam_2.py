def search_file(fileDir):
    f = open(fileDir, "r")
    return f

def search_word(fileDir):
    f = search_file(fileDir)
    Count = 0
    word = input("Search Word:")
    for line in f:
        if word.lower() in line:
            if line.startswith(word.lower()):
                print(line)
                Count+=1
            
    
    if Count==0:
            return 0

    return search_word(fileDir)

def main():
    fileDir = input("Specify word list file:")
    search_word(fileDir)
    return 0


if __name__ == '__main__':
    main()