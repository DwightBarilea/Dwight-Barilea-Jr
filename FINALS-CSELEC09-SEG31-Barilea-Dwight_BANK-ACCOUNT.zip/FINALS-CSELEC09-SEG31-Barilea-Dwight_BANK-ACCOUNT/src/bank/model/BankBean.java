package bank.model;

import javax.persistence.*;

@Entity (name="BankCustomerAccount")
public class BankBean {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String name;
	private double bankMoney;
	private String accountType;
	private double final_figure;
	private String remarks;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBankMoney() {
		return bankMoney;
	}
	public void setBankMoney(double bankMoney) {
		this.bankMoney = bankMoney;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getFinal_figure() {
		return final_figure;
	}
	public void setFinal_figure(double final_figure) {
		this.final_figure = final_figure;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public void savings_Deduction(){
		this.final_figure = (this.bankMoney > 2000)
				? this.bankMoney 
				: this.bankMoney - 200;
	}
	
	public void current_Deduction(){
		this.final_figure = (this.bankMoney > 5000)
				? this.bankMoney 
				: this.bankMoney - 500;
	}
	
	public void determineRemarks() {
		if(this.accountType.equals("Savings")==true){
			savings_Deduction();
			this.remarks = (this.bankMoney >= 2000)
					?"You do not have any deductions."
					:"Your balance is below the minimum of Php2000.00. The deduction is 200.00.\n"
							+ "Your new balance is " + this.final_figure;
		}else if(this.accountType.equals("Current")==true){
			current_Deduction();
			this.remarks = (this.bankMoney >= 5000)
					?"You do not have any deductions."
					:"Your balance is below the minimum of Php5000.00. The deduction is 500.00.\n"
					+ "Your new balance is " + this.final_figure;
		}
		else{
			this.remarks="You do not have any deductions.";
		}
	}
	
}
