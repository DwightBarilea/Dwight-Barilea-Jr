package bank.action;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import bank.model.BankBean;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class BankAccount extends ActionSupport implements ModelDriven <BankBean> {
	
	private BankBean Bank = new BankBean();
		
	public String execute() {
	
	Bank.determineRemarks();
		
	SessionFactory sessionFactory = 
			new Configuration().configure().buildSessionFactory();
		
	Session session = sessionFactory.openSession();
	session.beginTransaction();
	session.save(Bank);
	session.getTransaction().commit();
	
	System.out.println("Client Name: " + Bank.getName());
	System.out.println("Bank Account type is " + Bank.getAccountType());
	System.out.println(Bank.getFinal_figure());
	System.out.println(Bank.getRemarks());

		
	return SUCCESS;
	}
	
	public BankBean getBank(){
		return Bank;
	}
	
	public void setBank(BankBean Bank) {
		this.Bank = Bank;
	}
	
	@Override
	public BankBean getModel() {
		// TODO Auto-generated method stub
		return Bank;
	}
	
}
