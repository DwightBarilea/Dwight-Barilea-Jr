package model.Details;

public class Plate_Set_3Details extends Details{
	
	@Override
	public void setDisplayDescription() {
		this.displayDescription = "Designer plates made from ivory. Most commonly used for display.";
	}

	@Override
	public void setMadeFrom() {
		this.madeFrom = "Made in England.";
	}
	
	@Override
	public String getDisplayDescription() {
		return displayDescription;
	}

	@Override
	public String getMadeFrom() {
		return madeFrom;
	}

}
