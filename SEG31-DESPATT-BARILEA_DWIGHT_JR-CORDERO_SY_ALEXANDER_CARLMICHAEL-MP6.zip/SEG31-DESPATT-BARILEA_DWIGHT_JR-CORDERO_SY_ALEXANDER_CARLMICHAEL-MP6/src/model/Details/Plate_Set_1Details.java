package model.Details;

public class Plate_Set_1Details extends Details{

	@Override
	public void setDisplayDescription() {
		this.displayDescription = "A ceramic assortment of plates that are commonly used as dinner plates.";
	}

	@Override
	public void setMadeFrom() {
		this.madeFrom = "Made in China.";
	}

	@Override
	public String getDisplayDescription() {
		return displayDescription;
	}

	@Override
	public String getMadeFrom() {
		return madeFrom;
	}

}
