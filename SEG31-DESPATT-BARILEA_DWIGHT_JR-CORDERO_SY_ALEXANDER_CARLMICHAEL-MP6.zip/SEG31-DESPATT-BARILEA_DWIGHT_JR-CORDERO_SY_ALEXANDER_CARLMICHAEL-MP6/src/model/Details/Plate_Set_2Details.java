package model.Details;

public class Plate_Set_2Details extends Details{
	
	@Override
	public void setDisplayDescription() {
		this.displayDescription = "An assortment of utensils made from milk glass.";
	}
	
	@Override
	public void setMadeFrom() {
		this.madeFrom = "Made in China.";
	}

	@Override
	public String getDisplayDescription() {
		return displayDescription;
	}

	@Override
	public String getMadeFrom() {
		return madeFrom;
	}
	
}
