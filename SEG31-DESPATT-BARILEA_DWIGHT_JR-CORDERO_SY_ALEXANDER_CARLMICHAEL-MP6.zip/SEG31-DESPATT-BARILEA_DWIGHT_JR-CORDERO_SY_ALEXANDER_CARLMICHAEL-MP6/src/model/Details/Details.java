package model.Details;

public abstract class Details {
	
	String displayDescription;
	String madeFrom;
	
	public abstract void setDisplayDescription();
	public abstract void setMadeFrom();
	
	public abstract String getDisplayDescription();
	public abstract String getMadeFrom();
	
}
