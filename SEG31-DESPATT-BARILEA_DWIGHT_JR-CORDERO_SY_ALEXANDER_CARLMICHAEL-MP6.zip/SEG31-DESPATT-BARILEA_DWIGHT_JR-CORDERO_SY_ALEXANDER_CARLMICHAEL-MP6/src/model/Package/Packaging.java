package model.Package;

public abstract class Packaging {

	String pack;
	
	public abstract void setPackage();
	
	
	public abstract String getPackage();
	
}
