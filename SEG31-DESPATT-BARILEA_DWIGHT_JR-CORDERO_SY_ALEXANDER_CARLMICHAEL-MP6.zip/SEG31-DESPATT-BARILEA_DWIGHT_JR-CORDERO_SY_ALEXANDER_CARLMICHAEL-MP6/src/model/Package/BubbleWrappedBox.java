package model.Package;

public class BubbleWrappedBox extends Packaging{

	@Override
	public void setPackage() {
		this.pack = "Bubble Wrapped Box";
	}

	@Override
	public String getPackage() {
		// TODO Auto-generated method stub
		return this.pack;
	}
	
}
