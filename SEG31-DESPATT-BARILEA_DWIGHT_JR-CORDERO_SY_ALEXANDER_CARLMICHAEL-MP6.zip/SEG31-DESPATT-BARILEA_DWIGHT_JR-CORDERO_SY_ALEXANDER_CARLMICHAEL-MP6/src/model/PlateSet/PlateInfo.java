package model.PlateSet;

public class PlateInfo {
	String PlateSetName;
	double Prices;
	double Quantity;
	String packaging;
	
	public PlateInfo(String newPlateSetName, double newPrices, double newQuantity, String newPackage)
	{
		this.PlateSetName = newPlateSetName;
		this.Prices = newPrices;
		this.Quantity = newQuantity;
		this.packaging = newPackage;
	}
	
	public void setPlateSetName(String plateSetName) {
		this.PlateSetName = plateSetName;
	}

	public void setPrices(double viewPrices) {
		this.Prices = viewPrices;
	}
	
	public void setQuantity(double viewQuantity) {
		this.Quantity = viewQuantity;
	}
	
	public String getPlateSetName() {
		return PlateSetName;
	}

	public double getPrices() {
		return Prices;
	}

	public double getQuantity() {
		return Quantity;
	}

	public String getPackaging() {
		return packaging;
	}

	public void setPackaging(String packaging) {
		this.packaging = packaging;
	}


}
