package model.PlateSet;

import model.Details.*;
import model.Package.*;

public abstract class Plate {
	
	String plateSetName;
	String viewPieces;
	double viewPrices;
	double viewQuantity;
	String viewImages;
	
	public abstract void setPlateSetName();
	public abstract void setViewPieces();
	public abstract void setViewPrices();
	public abstract void setViewImages();
	public abstract void setViewQuantity();
	
	
	public abstract String getPlateSetName();
	public abstract String getViewPieces();
	public abstract double getViewPrices();
	public abstract String getViewImages();
	public abstract double getViewQuantity();

	public abstract void setDescription(Details desc);
	public abstract Details getDescription();
	
	public abstract void setPackaging(Packaging pack);
	public abstract Packaging getPackaging();
	
	public abstract Plate clone();
}
