package model.PlateSet;

import model.Details.*;
import model.Package.Packaging;

public class Plate_Set_2 extends Plate{
	
	private Details desc;
	private Packaging pack;
	
	public void setDescription(Details desc) {
		this.desc = desc;
	}
	
	@Override
	public void setPlateSetName(){
		this.plateSetName = "Plate Set 2";
		
	}
	
	@Override
	public void setViewPieces() {
		this.viewPieces = "6 tea plates, 4 soup plates, 2 soup bowls, 3 sauce bowls, 2 coffee cups,"
				+ "2 dinner plates, 1 serving platter, 4 knives & 2 forks.";
	}
	
	@Override
	public void setViewPrices() {
		this.viewPrices = 10000;
	}
	
	@Override
	public void setViewImages() {
		this.viewImages = "images/Plate_Set_2.jpg";
	}
	
	@Override
	public void setViewQuantity() {
		this.viewQuantity = 10;
		
	}

	@Override
	public String getPlateSetName() {
		return plateSetName;
	}

	@Override
	public String getViewPieces() {
		return viewPieces;
	}

	@Override
	public double getViewPrices() {
		return viewPrices;
	}

	@Override
	public String getViewImages() {
		return viewImages;
	}

	@Override
	public double getViewQuantity() {
		
		return viewQuantity;
	}
	
	public Details getDescription(){
		return desc;
	}
	
	@Override
	public Plate_Set_2 clone() {
		// TODO Auto-generated method stub
		return new Plate_Set_2();
	}

	@Override
	public void setPackaging(Packaging pack) {
		this.pack = pack;
		
	}

	@Override
	public Packaging getPackaging() {
		return pack;
	}


}
