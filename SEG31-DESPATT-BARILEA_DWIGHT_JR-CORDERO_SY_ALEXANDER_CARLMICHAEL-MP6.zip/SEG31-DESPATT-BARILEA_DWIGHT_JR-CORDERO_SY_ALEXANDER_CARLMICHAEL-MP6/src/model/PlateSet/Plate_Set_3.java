package model.PlateSet;

import model.Details.Details;
import model.Package.Packaging;

public class Plate_Set_3 extends Plate{
	
	private Details desc;
	private Packaging pack;
	
	public void setDescription(Details desc) {
		this.desc = desc;
	}
	
	@Override
	public void setPlateSetName() {
		this.plateSetName = "Plate Set 3";
	}
	
	@Override
	public void setViewPieces() {
		this.viewPieces = "4 Stylish Plates.";
	}
	
	@Override
	public void setViewPrices() {
		this.viewPrices = 4000;
	}
	
	@Override
	public void setViewImages() {
		this.viewImages = "images/Plate_Set_3.jpg";
	}
	
	@Override
	public void setViewQuantity() {
		this.viewQuantity = 10;
		
	}
	
	@Override
	public String getPlateSetName() {
		return plateSetName;
	}

	@Override
	public String getViewPieces() {
		return viewPieces;
	}

	@Override
	public double getViewPrices() {
		return viewPrices;
	}

	@Override
	public String getViewImages() {
		return viewImages;
	}
	
	@Override
	public double getViewQuantity() {
		return viewQuantity;
	}
	
	public Details getDescription(){
		return desc;
	}
	
	@Override
	public Plate_Set_3 clone() {
		// TODO Auto-generated method stub
		return new Plate_Set_3();
	}
	
	@Override
	public void setPackaging(Packaging pack) {
		this.pack = pack;
		
	}

	@Override
	public Packaging getPackaging() {
		return pack;
	}
}
