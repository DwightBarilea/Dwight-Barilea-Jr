package model.PlateSet;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import utility.PlateIterator;
import utility.SingletonDB;

public class Platos implements PlateIterator {

	ArrayList<PlateInfo> bestPlates;
	
	public  Platos() {
		bestPlates = new ArrayList<PlateInfo>();
	try {	
		ResultSet plate = SingletonDB.getAllShoppingCart();
		while(plate.next()) {
			String  plateName = plate.getString("name");
			double price = plate.getDouble("prices");
			double quantity = plate.getDouble("quantity");
			String packages = plate.getString("packaging");
			addPlate(plateName, price, quantity, packages);
			
		}
	}catch(SQLException sqe) {
		sqe.printStackTrace();
	}
	}
	
	public void addPlate(String plateName, double platePrice, double plateQuantity, String platePackaging){
		PlateInfo info = new PlateInfo(plateName, platePrice, plateQuantity, platePackaging);
		bestPlates.add(info);
	}
	
	public ArrayList<PlateInfo>getPlates(){
		return bestPlates;
	}

	
	@Override
	public Iterator createIterator() {
	
		return bestPlates.iterator();
	}
}	
	