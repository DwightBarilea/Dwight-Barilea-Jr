package model.PlateSet;

public interface ExceptionMessages {
	
	String EXPIRED_CREDIT_CARD = "ALERT!!! This credit card "
			+ "is expired. "
			+ "Get a scissor and cut the card.";
	
	String STOLEN_CREDIT_CARD = "ALERT!!! This Credit Card "
			+ "is stolen. "
			+ "Please call the police immediately to apprehend "
			+ "this criminal";
	
	String LUHN_FAILED_ALGORITHM = "ALERT!!! This card is invalid. "
			+ "Call the bank.";
	
	String INVALID_CCNUM_LENGTH = "ALERT!!! Invalid credit card number length";
	
	String INVALID_PRODUCT_PRICE = "ALERT!!! Invalid Price Range";

}
