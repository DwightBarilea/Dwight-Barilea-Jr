package model.PlateSet;

import model.Details.*;
import model.Package.*;

public class Plate_Set_1 extends Plate{
	
	private Details desc;
	private Packaging pack;

	@Override
	public void setPlateSetName() {
		this.plateSetName = "Plate Set 1";
	}

	@Override
	public void setViewPieces() {
		this.viewPieces = "6 plates with different variety of shapes.";
	}

	@Override
	public void setViewPrices() {
		this.viewPrices = 5000;
	}

	@Override
	public void setViewImages() {
		this.viewImages = "images/Plate_Set_1.jpg";
	}
	
	@Override
	public void setViewQuantity() {
		this.viewQuantity = 10;	
	}

	@Override
	public String getPlateSetName(){
		return plateSetName;
	}

	@Override
	public String getViewPieces() {
		return viewPieces;
	}

	@Override
	public double getViewPrices() {
		return viewPrices;
	}

	@Override
	public String getViewImages() {
		return viewImages;
	}
	
	@Override
	public double getViewQuantity() {
		return viewQuantity;
	}
	
	public void setDescription(Details desc) {
		this.desc = desc;
	}
	
	public Details getDescription(){
		return desc;
	}

	@Override
	public Plate_Set_1 clone() {
		return new Plate_Set_1();
	}

	@Override
	public void setPackaging(Packaging pack) {
		this.pack = pack;
		
	}

	@Override
	public Packaging getPackaging() {
		return pack;
	}

}
