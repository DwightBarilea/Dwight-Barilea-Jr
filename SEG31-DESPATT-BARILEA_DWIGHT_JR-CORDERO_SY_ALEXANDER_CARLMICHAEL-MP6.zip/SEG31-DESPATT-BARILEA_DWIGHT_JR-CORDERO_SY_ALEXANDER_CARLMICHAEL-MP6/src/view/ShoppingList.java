package view;

import model.Details.Plate_Set_1Details;
import model.Details.Plate_Set_2Details;
import model.Details.Plate_Set_3Details;
import model.PlateSet.Plate;
import model.PlateSet.Plate_Set_1;
import model.PlateSet.Plate_Set_2;
import model.PlateSet.Plate_Set_3;

public class ShoppingList{
	public static void viewDetails(Plate plateSetType) {
		
		if (plateSetType instanceof Plate_Set_1) {
			Plate_Set_1 Plates1 = (Plate_Set_1) plateSetType;
			Plates1.setPlateSetName();
			Plates1.setViewPieces();
			Plates1.setViewPrices();
			Plates1.setViewImages();
			Plates1.setViewQuantity();
			
			Plate_Set_1Details PlatesDetails1 = (Plate_Set_1Details) plateSetType.getDescription();
			
			PlatesDetails1.setDisplayDescription();
			PlatesDetails1.setMadeFrom();
		
		}else if (plateSetType instanceof Plate_Set_2) {
			Plate_Set_2 Plates2 = (Plate_Set_2) plateSetType;
			Plates2.setPlateSetName();
			Plates2.setViewPieces();
			Plates2.setViewPrices();
			Plates2.setViewImages();
			Plates2.setViewQuantity();
			
			Plate_Set_2Details PlatesDetails2 = (Plate_Set_2Details) plateSetType.getDescription();
			
			PlatesDetails2.setDisplayDescription();
			PlatesDetails2.setMadeFrom();
			
		}else if (plateSetType instanceof Plate_Set_3) {
			Plate_Set_3 Plates3 = (Plate_Set_3) plateSetType;
			Plates3.setPlateSetName();
			Plates3.setViewPieces();
			Plates3.setViewPrices();
			Plates3.setViewImages();
			Plates3.setViewQuantity();
			
            Plate_Set_3Details PlatesDetails3 = (Plate_Set_3Details) plateSetType.getDescription();
			
			PlatesDetails3.setDisplayDescription();
			PlatesDetails3.setMadeFrom();
		}
		
	}
}
