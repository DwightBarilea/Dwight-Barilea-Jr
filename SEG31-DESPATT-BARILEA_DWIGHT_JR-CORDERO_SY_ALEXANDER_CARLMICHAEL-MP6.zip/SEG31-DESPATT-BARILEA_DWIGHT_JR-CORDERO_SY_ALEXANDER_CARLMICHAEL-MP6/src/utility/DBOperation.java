package utility;

public interface DBOperation {
	
	String CREATE_TABLE = "create table  IF NOT EXISTS PlateSets ("
            + "id int(50) NOT NULL AUTO_INCREMENT,"
            + "name varchar(255) NOT NULL,"
            + "setTypes varchar(255) NOT NULL,"
            + "prices double NOT NULL,"
            + "images varchar(255) NOT NULL,"
            + "descrip varchar(255) NOT NULL,"
            + "made varchar(255) NOT NULL,"
            + "quantity double NOT NULL,"
            + "PRIMARY KEY (id))";
		
	
		String INSERT_RECORD = "insert into PlateSets (name, setTypes, prices, "
			+ "images, descrip, made, quantity) values (?,?,?,?,?,?,?)";
		
		String DEDUCT_RECORD = "UPDATE platesets"
				+ "SET quantity = quantity - 1"
				+ "WHERE name LIKE ?";
		
		String ADJUST_RECORD = "UPDATE platesets INNER JOIN shoppingcart on platesets.name = shoppingcart.name SET platesets.quantity= platesets.quantity - shoppingcart.quantity";
		
		String GET_ALL_RECORDS = "SELECT * from PlateSets";
		
		String SEARCH_RECORDS = "SELECT * from PlateSets WHERE name LIKE ?";
		
		String CREATE_SHOPPING_CART = "create table  IF NOT EXISTS ShoppingCart ("
		        + "id int(255) NOT NULL AUTO_INCREMENT,"
		        + "name varchar(255) NOT NULL,"
		        + "prices double NOT NULL,"
		        + "quantity double NOT NULL,"
		        + "packaging varchar(255) NOT NULL,"
		        + "PRIMARY KEY (id))";
		
//		String ADJUST_CART = "IF EXISTS(select * from ShoppingCart WHERE name = ?)"
//				+ "THEN UPDATE ShoppingCart SET quantity = quantity + ? WHERE name = ?"
//				+ "ELSE insert into ShoppingCart(name, prices, quantity) values(? , ? , ?)";
		
//		String ADJUST_CART = "INSERT INTO ShoppingCart (name, prices, quantity) VALUES(?, ?, ?) ON "
//				+ "DUPLICATE KEY UPDATE name= ?, prices = ?, quantity = quantity + ?";
		
//		String ADJUST_CART = "IF EXISTS (SELECT * FROM shoppingcart WHERE name = ?)"
//				+"BEGIN "
//				+ "UPDATE ShoppingCart SET quantity = quantity + ? WHERE name = ?"
//				+" END" 
//				+"ELSE "
//				+"BEGIN "
//				+"INSERT INTO ShoppingCart (name, prices, quantity) VALUES(?, ?, ?)"
//				+" END";

		String ADJUST_CART = "UPDATE ShoppingCart SET quantity = quantity + ? WHERE name = ?";
				
	
		
		
		
//		IF EXISTS(select * from test where id=30122)
//		   update test set name='john' where id=3012
//		ELSE
//		   insert into test(name) values('john');
		
		String DELETE_RECORD = "UPDATE ShoppingCart SET quantity = 0 WHERE name = ?";
		
		
		String INSERT_TO_SHOPPING_CART = "insert into ShoppingCart (name, prices, quantity, packaging) "
				+ "values (?,?,?,?)";
		
		String SHOPPING_CART_CONTENTS = "SELECT * from ShoppingCart WHERE quantity > 0";
}
