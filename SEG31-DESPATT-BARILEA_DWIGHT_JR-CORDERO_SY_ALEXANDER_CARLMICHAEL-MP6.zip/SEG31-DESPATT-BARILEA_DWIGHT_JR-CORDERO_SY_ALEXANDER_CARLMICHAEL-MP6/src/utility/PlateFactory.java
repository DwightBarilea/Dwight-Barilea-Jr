package utility;

import java.util.HashMap;
import java.util.Map;


import model.PlateSet.*;

public class PlateFactory {
	
	public Plate getPlates(String plateType){
		Plate dish = null;
		
		switch(plateType) {
		
		case "PLATES1":
			dish = new Plate_Set_1();
			break;
		case "PLATES2":
			dish = new Plate_Set_2();
			break;
			
		case "PLATES3":
			dish = new Plate_Set_3();
			break;
	}
		
		return dish;
	}
	
	private static final Map<String, Plate> prototypes = new HashMap<>();
	static {
		
		prototypes.put("PLATE SET 1", new Plate_Set_1());
		prototypes.put("PLATE SET 2", new Plate_Set_2());
		prototypes.put("PLATE SET 3", new Plate_Set_3());
	}
	
	public static Plate getPrototype(String type) {
    	System.out.println("inside getPrototype()");
    	try {
            return prototypes.get(type).clone();
        } catch (NullPointerException ex) {
            System.out.println("Prototype with name: " + type + ", doesn't exist");
            return null;
        }
    }
	
	
}
