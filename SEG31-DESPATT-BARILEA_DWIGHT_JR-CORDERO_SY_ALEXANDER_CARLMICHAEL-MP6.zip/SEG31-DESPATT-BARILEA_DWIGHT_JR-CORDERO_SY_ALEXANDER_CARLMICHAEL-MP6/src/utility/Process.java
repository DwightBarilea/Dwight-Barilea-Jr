package utility;

import java.sql.SQLException;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;




public class Process implements Facade{

	public static boolean cardValidation (String ccNumber){
				boolean isValid = false;
				int lengthCounter = ccNumber.length();
				
				if (lengthCounter != 16) {
					System.err.println("Error Invalid credit card length");
					}
				else {
					if (luhnTest(ccNumber) == false){
						System.err.println("Luhn algorithm failed");
					
						} 
					else{
						System.out.println("Credit Card is valid");
					}
					isValid = true;
				}
				return isValid;
				
			}
	
	
	
	
	public static boolean luhnTest(String number){
		boolean checker = false;
        int s1 = 0;
        int s2 = 0;
        
        String reverse = new StringBuffer(number).reverse().toString();
        for(int i = 0 ;i < reverse.length();i++){
            int digit = Character.digit(reverse.charAt(i), 10);
            if(i % 2 == 0){//this is for odd digits, they are 1-indexed in the algorithm
                s1 += digit;
            }else{//add 2 * digit for 0-4, add 2 * digit - 9 for 5-9
                s2 += 2 * digit;
                if(digit >= 5){
                    s2 -= 9;
                }
            }
        } if ((s1 + s2) % 10 == 0){
        	checker = true;
        } else {
        	checker = false;
        }
        return checker;
	}
	
	
	 public void SendAttachment(){  
		 
          String to="201801021@iacademy.edu.ph";//change accordingly  
		  final String user="bscsmail.se31@gmail.com";//change accordingly  
		  final String password="BSCS-SE31";//change accordingly  
		   
		  //1) get the session object     
		  Properties properties = System.getProperties();  
		  properties.setProperty("mail.smtp.host", "smtp.gmail.com");  
		  properties.put("mail.smtp.auth", "true");  
		  
		  Session session = Session.getDefaultInstance(properties,  
		   new javax.mail.Authenticator() {  
		   protected PasswordAuthentication getPasswordAuthentication() {  
		   return new PasswordAuthentication(user,password);  
		   }  
		  });  
		  try {
				SingletonDB.viewTable();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  //2) compose message     
		  try{  
		    MimeMessage message = new MimeMessage(session);  
		    message.setFrom(new InternetAddress(user));  
		    message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
		    message.setSubject("Your Plates");  
		      
		    //3) create MimeBodyPart object and set your message text     
		    BodyPart messageBodyPart1 = new MimeBodyPart();  
		    messageBodyPart1.setText("Plate Order successful!"
		    		+ "Thank you for Plating with us!"
		    		+ "Here's your receipt!");  
		      
		    //4) create new MimeBodyPart object and set DataHandler object to this object      
		    MimeBodyPart messageBodyPart2 = new MimeBodyPart();  
		  
		    String filename = "D:\\receipt.pdf";//change accordingly  
		    DataSource source = new FileDataSource(filename);  
		    messageBodyPart2.setDataHandler(new DataHandler(source));  
		    messageBodyPart2.setFileName(filename);  
		   
		     
		     
		    //5) create Multipart object and add MimeBodyPart objects to this object      
		    Multipart multipart = new MimeMultipart();  
		    multipart.addBodyPart(messageBodyPart1);  
		    multipart.addBodyPart(messageBodyPart2);  
		  
		    //6) set the multiplart object to the message object  
		    message.setContent(multipart );  
		     
		    //7) send message  
		    Transport.send(message);  
		   
		   System.out.println("message sent....");  
		   }catch (MessagingException ex) {ex.printStackTrace();}  
		 }
	 
	 
	//Facade 
	 @Override
	 public void process(String ccNumber){
		
		if(cardValidation(ccNumber)==true){
		Mailer.send("bscsmail.se31@gmail.com","BSCS-SE31","bscsmail.se31@gmail.com","hello javatpoint","How r u?");  
		SendAttachment();
		try {
			SingletonDB.reduceStock();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		else{
		}
	 }
	 
}//end of Process class


