package utility;

public interface Facade {
	
	//public void process();

	void process(String ccNumber);

}
