package utility;

import model.Details.*;
import model.PlateSet.*;

public interface AbstractFactory {

	Plate getPlates(String plateSetType);
	Details getDescription(String plateSetType);
	
}
