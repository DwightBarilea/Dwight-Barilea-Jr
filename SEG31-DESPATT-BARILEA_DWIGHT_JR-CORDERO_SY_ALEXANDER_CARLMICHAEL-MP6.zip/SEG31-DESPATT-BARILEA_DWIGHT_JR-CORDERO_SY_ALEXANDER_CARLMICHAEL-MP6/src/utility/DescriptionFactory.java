package utility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import model.Details.*;

public class DescriptionFactory implements DBOperation {
	
	public Details getDescription(String plateType){
		Details details = null;
		
		if(plateType.equalsIgnoreCase("Plate Set 1")) {
			details = new Plate_Set_1Details();
		} else if (plateType.equalsIgnoreCase("Plate Set 2")) {
			details = new Plate_Set_2Details();
		} else if(plateType.equalsIgnoreCase("Plate Set 3")) {
			details = new Plate_Set_3Details();
		} 
		
		return details;
		
	}
	
//	public Details getDescription(String plateType){
//		Details details = null;
//		
//		Connection connection = getConnection();
//		System.out.println("Boop");
//	      if (connection != null) {
//				try {
//					
//					ResultSet records = SingletonDB.searchRecord(plateType);
//					System.out.println("Pooob");
//				            	while (records.next()){
//				                System.out.println("CUUUU");
//				            	System.out.println(records.getString("name"));
//								if(records.getString("name").equalsIgnoreCase("Plate Set 1")) {
//										details = new Plate_Set_1Details();
//								} else if (records.getString("name").equalsIgnoreCase("Plate Set 2")) {
//										details = new Plate_Set_2Details();
//								} else if(records.getString("name").equalsIgnoreCase("Plate Set 3")) {
//										details = new Plate_Set_3Details();
//								} 
//				            
//				        	}
//				      }
//				catch (SQLException sqle) {
//					sqle.printStackTrace();
//				}
//			} 
//		
//		return details;
//		
//	}

//private static Connection connection; 
//
//public static Connection getConnection() {
//	return (( connection !=null )
//		? connection
//		: getDBConnection());		
//}
//
//
//private static Connection getDBConnection()  {
//	Connection connection = null;
//
//		//Context initContext;
//		try {
//
//			connection = ((DataSource)InitialContext.doLookup("java:/comp/env/jdbc/SEG31_DS"))
//					.getConnection();
//
//		} catch (NamingException e) {
//			e.printStackTrace();
//		} catch (SQLException sqle) {
//			sqle.printStackTrace();
//		}
//	return connection;
//}


}
