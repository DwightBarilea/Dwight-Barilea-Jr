package utility;

import java.util.Iterator;

public interface PlateIterator {
	public Iterator createIterator();
}
