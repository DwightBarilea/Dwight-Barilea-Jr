package utility;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.*;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import model.Details.*;
import model.Package.BubbleWrappedBox;
import model.PlateSet.*;

public class SingletonDB implements DBOperation {


	//this is defaulted to null
	private static Connection connection; 
	
	public SingletonDB() {
	}
	
////////////
//CONNECTION
	private static Connection getDBConnection()  {
		Connection connection = null;

			//Context initContext;
			try {

				connection = ((DataSource)InitialContext.doLookup("java:/comp/env/jdbc/SEG31_DS"))
						.getConnection();

			} catch (NamingException e) {
				e.printStackTrace();
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		return connection;
	}
	
	//now this is the global method that can be accessed statically by
	//other classes when creating a Connection object
	public static Connection getConnection() {
		return (( connection !=null )
			? connection
			: getDBConnection());		
	}
		

/////////////
//GET RECORDS
	public ResultSet getAllRecords() {
		ResultSet records = null;
		Connection connection = getConnection();

		if (connection != null) {
			try {
				PreparedStatement pstmnt = connection.prepareStatement(GET_ALL_RECORDS);

				records = pstmnt.executeQuery();
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		} 
		return records;
	}
	
	//////////////
	//CREATE TABLE	
	public static void createTable() throws SQLException{
		connection = getDBConnection();

		if(connection != null){
			PreparedStatement prep = connection.prepareStatement(CREATE_TABLE);
			prep.executeUpdate();
			prep.close();
			}
	}
	
	public static void insertRecord(String name,String pieces,double prices,String images,String desc,String made, double quantity) {
		Connection connection = getDBConnection();
	
			if (connection != null) {
				try {
					connection.setAutoCommit(false);
					//create a PreparedStavitement object
					PreparedStatement prep = connection.prepareStatement(INSERT_RECORD);
					
					prep.setString(1, name);
					prep.setString(2, pieces);
					prep.setDouble(3, prices);
					prep.setString(4, images);
					prep.setString(5, desc);
					prep.setString(6, made);
					prep.setDouble(7, quantity);
					
					//now commit this to the database table
					prep.executeUpdate();
					connection.commit();
					
				} catch (Exception e) {
					try {
						connection.rollback();
					} catch (SQLException sqle) {
						e.printStackTrace();
					}
					e.printStackTrace();
				}
				
			}
		
	}
	
	public static void  insertPlates() throws SQLException{
		Connection connection = getDBConnection();
		ResultSet records;
		
		PreparedStatement prep = connection.prepareStatement(GET_ALL_RECORDS);

		records = prep.executeQuery();
			if (connection != null) {
				try {
					connection.setAutoCommit(false);
					if(records.next()){
						
					}
					else{
						Plate_Set_1 Plates1 = new Plate_Set_1();
						Plates1.setPlateSetName();
						Plates1.setViewPieces();
						Plates1.setViewPrices();
						Plates1.setViewImages();
						Plates1.setViewQuantity();
						
						Plate_Set_1Details PlatesDetails1 = new Plate_Set_1Details();
						
						PlatesDetails1.setDisplayDescription();
						PlatesDetails1.setMadeFrom();
						
						BubbleWrappedBox WrappedBox1 = new BubbleWrappedBox();
						
						WrappedBox1.setPackage();
						
						insertRecord(Plates1.getPlateSetName(), Plates1.getViewPieces(),Plates1.getViewPrices(), Plates1.getViewImages(), PlatesDetails1.getDisplayDescription(), PlatesDetails1.getMadeFrom(), Plates1.getViewQuantity());
						insert_ShoppingCart(Plates1.getPlateSetName(), Plates1.getViewPrices(), 0, WrappedBox1.getPackage());
						
						
						Plate_Set_2 Plates2 = new Plate_Set_2();
						Plates2.setPlateSetName();
						Plates2.setViewPieces();
						Plates2.setViewPrices();
						Plates2.setViewImages();
						Plates2.setViewQuantity();
						
						
						Plate_Set_2Details PlatesDetails2 = new Plate_Set_2Details();
						
						PlatesDetails2.setDisplayDescription();
						PlatesDetails2.setMadeFrom();
						
						BubbleWrappedBox WrappedBox2 = new BubbleWrappedBox();
						
						WrappedBox2.setPackage();
						
					
						insertRecord(Plates2.getPlateSetName(), Plates2.getViewPieces(),Plates2.getViewPrices(), Plates2.getViewImages(), PlatesDetails2.getDisplayDescription(), PlatesDetails2.getMadeFrom(), Plates2.getViewQuantity() );
						insert_ShoppingCart(Plates2.getPlateSetName(), Plates2.getViewPrices(), 0, WrappedBox2.getPackage());
						
						
						
						Plate_Set_3 Plates3 = new Plate_Set_3();
						Plates3.setPlateSetName();
						Plates3.setViewPieces();
						Plates3.setViewPrices();
						Plates3.setViewImages();
						Plates3.setViewQuantity();
						
			            Plate_Set_3Details PlatesDetails3 = new Plate_Set_3Details();
			           
						PlatesDetails3.setDisplayDescription();
						PlatesDetails3.setMadeFrom();
						
						BubbleWrappedBox WrappedBox3 = new BubbleWrappedBox();
						
						WrappedBox3.setPackage();
						
						insertRecord(Plates3.getPlateSetName(), Plates3.getViewPieces(),Plates3.getViewPrices(), Plates3.getViewImages(), PlatesDetails3.getDisplayDescription(), PlatesDetails3.getMadeFrom(), Plates3.getViewQuantity());
						insert_ShoppingCart(Plates3.getPlateSetName(), Plates3.getViewPrices(), 0, WrappedBox3.getPackage());
						
				}
			} catch (Exception e) {
				try {
					connection.rollback();
				} catch (SQLException sqle) {
					e.printStackTrace();
				}
				e.printStackTrace();
			}
					
					
	}

	}
	
	public static ResultSet searchRecord(String name) throws SQLException{
		ResultSet records = null;
		Connection connection = getDBConnection();

		if (connection != null) {
			try {
				PreparedStatement prep = connection.prepareStatement(SEARCH_RECORDS);
				
				prep.setString(1, "%" + name +"%");
				
				
				records = prep.executeQuery();
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		} 
		return records;
	}
	
	public static ResultSet reduceStock() throws SQLException{
		ResultSet records = null;
		Connection connection = getDBConnection();

		if (connection != null) {
			try {
				PreparedStatement prep = connection.prepareStatement(ADJUST_RECORD);
				
				prep.executeUpdate();
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		} 
		return records;
	}
	
	public boolean isRecordDeleted(String name) {
		boolean isDeleted = false;
		Connection connection = getConnection();
		
		if (connection != null) {
			try {
				connection.setAutoCommit(false); //start of transaction
				PreparedStatement pstmnt = connection.prepareStatement(DELETE_RECORD);
				
				pstmnt.setString(1, name);
				
				pstmnt.executeUpdate();
				connection.commit();
				isDeleted = true;
			} catch (SQLException sqle) {
				try {
					connection.rollback();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				sqle.printStackTrace();
			}
		} 
		return isDeleted;
	}
	
	public boolean isRecordUpdated(String name, double quantity){
		boolean isUpdated = false;
		Connection connection = getConnection();
		
		if (connection != null) {
			try {
				connection.setAutoCommit(false); //start of transaction
				PreparedStatement pstmnt = connection.prepareStatement(ADJUST_CART);
				
//				pstmnt.setString(1, name);
//				pstmnt.setDouble(2, prices);
//				pstmnt.setDouble(3, quantity);
//				pstmnt.setString(4, name);
//				pstmnt.setDouble(5, prices);
//				pstmnt.setDouble(6, quantity);
				
				pstmnt.setDouble(1, quantity);
				pstmnt.setString(2, name);
				
				pstmnt.executeUpdate();
				connection.commit();
				isUpdated = true;
			} catch (SQLException sqle) {
				try {
					connection.rollback();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				sqle.printStackTrace();
			}
		} 
		return isUpdated;
	}
	
	public static void createShoppingCart() throws SQLException{
		connection = getDBConnection();

		if(connection != null){
			PreparedStatement prep = connection.prepareStatement(CREATE_SHOPPING_CART);
			prep.executeUpdate();
			prep.close();
			}
	}
	
	public static void insert_ShoppingCart(String name,double prices,double quantity, String packaging) {
	Connection connection = getDBConnection();
	
			if (connection != null) {
				try {
					connection.setAutoCommit(false);
					//create a PreparedStavitement object
					PreparedStatement prep = connection.prepareStatement(INSERT_TO_SHOPPING_CART);
					System.out.println("Entering");
					prep.setString(1, name);
					prep.setDouble(2, prices);
					prep.setDouble(3, quantity);
					prep.setString(4, packaging);
					
					//now commit this to the database table
					prep.executeUpdate();
					connection.commit();
					
				} catch (Exception e) {
					try {
						connection.rollback();
					} catch (SQLException sqle) {
						e.printStackTrace();
					}
					e.printStackTrace();
				}
				
			}
		
	}
	
	public static ResultSet getAllShoppingCart() {
		ResultSet records = null;
		Connection connection = getConnection();

		if (connection != null) {
			try {
				PreparedStatement pstmnt = connection.prepareStatement(SHOPPING_CART_CONTENTS);

				records = pstmnt.executeQuery();
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		} 
		return records;
	}
	
	public static void viewTable() throws SQLException {
		Connection connection = getConnection();
		PreparedStatement pstmnt = connection.prepareStatement(SHOPPING_CART_CONTENTS);
		
	      if (connection != null) {
				try {
					ResultSet rs = pstmnt.executeQuery(SHOPPING_CART_CONTENTS);
				     
				        
				        String FILE = "D:\\receipt.pdf";
						System.out.println("i'm gonna write");
				        try {
				        	
				            Document document = new Document();
				            PdfWriter.getInstance(document, new FileOutputStream(FILE));
				            document.open();
				            while (rs.next()) {
								  String name = rs.getString("name");
								  double prices = rs.getInt("prices");
								  double quantity = rs.getFloat("quantity");
								  String pack = rs.getString("packaging");
				            document.add(new Paragraph(name +", "+ prices +", " + quantity + "," + pack));
				        	}
				            document.close();// no need to close PDFwriter
				        
				        	
				        }catch (DocumentException de) {
				        	de.printStackTrace();
				        }catch (FileNotFoundException fnfe){
				        	fnfe.printStackTrace();
				        }catch (Exception e){
				            e.printStackTrace();
				        }
				        
				        
				      }
				catch (SQLException sqle) {
					sqle.printStackTrace();
				}
			} 
	  }
	
}
