package controller;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utility.*;
import utility.Process;


public class paymentConfirmed extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private String card;

	public void init()throws ServletException {
		card = "";
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
//			name = request.getParameter("name");
//			quantity = Double.parseDouble(request.getParameter("name"));
			card = request.getParameter("creditCard");
			
			System.out.println("card");
			
			
			
			Process proc = new Process();
			proc.process(card);
		
			
			ResultSet records = SingletonDB.getAllShoppingCart();
			request.setAttribute("records", records);
			request.getRequestDispatcher("index.jsp").forward(request, response);
			
		} catch (Exception e) {
			e.getMessage();
		}
		
	}
}