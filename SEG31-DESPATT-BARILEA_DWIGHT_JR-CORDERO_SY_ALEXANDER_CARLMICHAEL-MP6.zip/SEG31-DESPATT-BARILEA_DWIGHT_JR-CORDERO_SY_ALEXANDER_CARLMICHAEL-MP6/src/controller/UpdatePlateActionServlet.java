package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utility.SingletonDB;

public class UpdatePlateActionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		double quantity = Double.parseDouble(request.getParameter("quantity"));
		if (new SingletonDB().isRecordUpdated(name, quantity)) {
			java.sql.ResultSet records = new SingletonDB().getAllRecords();
			
			//perform object data binding
			request.setAttribute("records", records);
			request.getRequestDispatcher("catalogue.jsp").forward(request, response);
		} else {
			//TODO
		}
	}

}
