package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.PlateSet.PlateInfo;
import model.PlateSet.Platos;
import utility.*;



public class paymentConfirmation extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void iterate() {
		Platos platos;
		
		platos = new Platos();
		
		printPlates(platos);
		
	}
	
	public static void printPlates(PlateIterator plateItr) {
		Iterator<PlateInfo> itr = plateItr.createIterator();
		
		while(itr.hasNext()) {
			PlateInfo bestPlates = (PlateInfo) itr.next();
			System.out.println("\nplateName: " + bestPlates.getPlateSetName());
			System.out.println("Price: " + bestPlates.getPrices());
			System.out.println("Quantity:; " + bestPlates.getQuantity());
			System.out.println("Packaging: " + bestPlates.getPackaging());
		}
		
	}
	
	public void init()throws ServletException {
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			iterate();
			ResultSet records = SingletonDB.getAllShoppingCart();
			
			request.setAttribute("records", records);
			request.getRequestDispatcher("paymentConfirmation.jsp").forward(request, response);
			
		} catch (Exception e) {
			e.getMessage();
		}
		
	}
}