package controller;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Details.Details;
import model.PlateSet.*;
import utility.*;


public class Shopping extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private String plate; //defaulted to null
	public void init()throws ServletException {
		plate = "";
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			plate = request.getParameter("name");
			Plate plato = new PlateFactory().getPlates(plate);
			Details desc = new DescriptionFactory().getDescription(plate);
			
//			plato.getPlateSetName();
//			plato.getViewPrices();
			//System.out.println(desc.getDisplayDescription());
			
			ResultSet records = SingletonDB.searchRecord(plate);
			request.setAttribute("records", records);
			RequestDispatcher dispatcher = request.getRequestDispatcher("display-jsp20.jsp");
			dispatcher.forward(request, response);
			
		} catch (Exception e) {
			e.getMessage();
		}
		
	
		
		Plate protoPlate = PlateFactory.getPrototype(plate);
		
		if(protoPlate !=null) {
			System.out.println("Insert Prototype: " + protoPlate.toString());
		}
	}	
	
}
